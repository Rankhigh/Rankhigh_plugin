<?php
function esc_url_raw( $value ) { return filter_var( $value, FILTER_SANITIZE_URL ); }
function esc_xml( $value ) { return htmlspecialchars( (string) $value, ENT_XML1 | ENT_COMPAT, 'UTF-8' ); }
function wp_strip_all_tags( $value ) { return strip_tags( $value ); }
function get_option( $key, $default = false ) { return $default; }
function get_post_meta( $post_id, $key, $single = true ) { return '_rankhigh_seo_focus_keyword' === $key ? 'climate news' : ''; }
function wp_parse_url( $url, $component = -1 ) { return $component === -1 ? parse_url( $url ) : ( parse_url( $url, $component ) ?: null ); }
function set_url_scheme( $url ) { return $url; }
function home_url( $path = '/' ) { return 'https://example.test' . $path; }
function sanitize_key( $value ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ); }
function absint( $value ) { return abs( (int) $value ); }
require_once __DIR__ . '/../src/Sitemap/Providers/SitemapProviderInterface.php';
require_once __DIR__ . '/../src/Sitemap/Engine/SitemapRenderer.php';
require_once __DIR__ . '/../src/Sitemap/Engine/SitemapIndex.php';
require_once __DIR__ . '/../src/Core/PublicationProfile.php';
require_once __DIR__ . '/../src/SEO/KeywordDensityChecker.php';
require_once __DIR__ . '/../src/Meta/MetaGenerator.php';
$xml = \RankHighSEO\Sitemap\Engine\SitemapRenderer::url( 'https://example.test/a?x=1&y=2', '2026-01-01T00:00:00+00:00' );
if ( false === strpos( $xml, '&amp;' ) || false === strpos( $xml, '<lastmod>' ) ) { exit( 1 ); }
$image_xml = \RankHighSEO\Sitemap\Engine\SitemapRenderer::image( 'https://example.test/image.jpg', 'Headline image', 'Caption text', '', 'https://example.test/license' );
if ( false === strpos( $image_xml, '<image:caption>Caption text</image:caption>' ) || false === strpos( $image_xml, '<image:license>https://example.test/license</image:license>' ) ) { exit( 8 ); }
$provider = new class implements \RankHighSEO\Sitemap\Providers\SitemapProviderInterface { public function get_name() { return 'Test'; } public function get_slug() { return 'test'; } public function is_enabled() { return true; } public function get_shard_count() { return 2; } public function render_shard( $shard ) { return ''; } };
$index = ( new \RankHighSEO\Sitemap\Engine\SitemapIndex() )->render( array( $provider ) );
if ( substr_count( $index, '<sitemap>' ) !== 2 || false === strpos( $index, 'rankhigh-test-sitemap-2.xml' ) ) { exit( 2 ); }
if ( '' !== \RankHighSEO\Core\PublicationProfile::normalize_url( 'http://localhost/wp-admin/' ) ) { exit( 3 ); }
if ( 'https://images.example.test/media/a.jpg' !== \RankHighSEO\Core\PublicationProfile::normalize_url( 'https://images.example.test/media/a.jpg' ) ) { exit( 4 ); }
$analysis = ( new \RankHighSEO\SEO\KeywordDensityChecker() )->analyze( (object) array( 'ID' => 1, 'post_title' => 'Climate news', 'post_content' => 'Climate news is important. ' . str_repeat( 'editorial context ', 150 ) . 'Climate news affects policy.' ) );
if ( 3 !== $analysis['count'] || 'healthy' !== $analysis['status'] ) { exit( 5 ); }
require_once __DIR__ . '/../src/Admin/ImportExport.php';
$meta = new \RankHighSEO\Meta\MetaGenerator();
if ( 'noindex,nofollow,noarchive' !== $meta->normalize_robots( 'index,noindex,follow,nofollow,noarchive,unsupported' ) ) { exit( 6 ); }
$reflection = new ReflectionClass( '\RankHighSEO\Admin\ImportExport' );
$property = $reflection->getProperty( 'allowed' ); $property->setAccessible( true );
$allowed = $property->getValue( $reflection->newInstanceWithoutConstructor() );
if ( in_array( 'rankhigh_indexnow_key', $allowed, true ) ) { exit( 7 ); }
echo "smoke tests passed\n";
