<?php
/** Opt-in, bounded 404 monitor with privacy-conscious aggregation. */
namespace RankHighSEO\Monitor;

defined( 'ABSPATH' ) || exit;

final class NotFoundMonitor {
	public function register() { add_action( 'template_redirect', array( $this, 'capture' ), 1 ); }

	public function capture() {
		if ( ! get_option( 'rankhigh_seo_404_monitor', false ) || ! is_404() || wp_doing_ajax() || is_admin() ) { return; }
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$path = sanitize_text_field( wp_parse_url( $path, PHP_URL_PATH ) ?: '/' );
		$referrer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
		$agent = strtolower( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) );
		$category = false !== strpos( $agent, 'bot' ) || false !== strpos( $agent, 'spider' ) || false !== strpos( $agent, 'crawler' ) ? 'crawler' : ( false !== strpos( $agent, 'mobile' ) ? 'mobile' : 'browser' );
		$log = get_option( 'rankhigh_seo_404_log', array() ); $log = is_array( $log ) ? $log : array(); $found = false;
		foreach ( $log as &$entry ) {
			if ( is_array( $entry ) && (string) ( $entry['path'] ?? '' ) === $path && (string) ( $entry['agent_category'] ?? '' ) === $category ) {
				$entry['count'] = min( 1000000, absint( $entry['count'] ?? 1 ) + 1 ); $entry['last_seen'] = current_time( 'mysql', true ); $found = true; break;
			}
		}
		unset( $entry );
		if ( ! $found ) { $log[] = array( 'path' => $path, 'time' => current_time( 'mysql', true ), 'last_seen' => current_time( 'mysql', true ), 'count' => 1, 'referrer' => $referrer, 'agent_category' => $category, 'resolved' => false ); }
		usort( $log, static function ( $a, $b ) { return strcmp( (string) ( $b['last_seen'] ?? '' ), (string) ( $a['last_seen'] ?? '' ) ); } );
		update_option( 'rankhigh_seo_404_log', array_slice( $log, 0, 500 ), false );
	}
}
