<?php
namespace RankHighSEO\Core;

use RankHighSEO\Meta\HeadOutput;
use RankHighSEO\Meta\LanguageAlternates;
use RankHighSEO\Schema\GraphOutput;
use RankHighSEO\Sitemap\SitemapController;
use RankHighSEO\Redirect\RedirectController;
use RankHighSEO\Admin\SettingsPage;
use RankHighSEO\Admin\DiagnosticsPage;
use RankHighSEO\Admin\ImportExport;
use RankHighSEO\Admin\DashboardPage;
use RankHighSEO\Compatibility\JNewsAdapter;
use RankHighSEO\Monitor\NotFoundMonitor;
use RankHighSEO\SEO\AdvancedFeatures;
use RankHighSEO\SEO\YoastParityFeatures;
use RankHighSEO\Indexing\IndexNow;
use RankHighSEO\SEO\BreadcrumbEngine;
use RankHighSEO\Security\TraceIntegrity;

final class Plugin {
	private $registry;
	public function boot() {
		if ( did_action( 'rankhigh_seo_loaded' ) ) {
			return;
		}
		// RankHigh is intentionally focused on publisher/news sites and only owns post output.
		if ( ! post_type_exists( 'post' ) ) {
			return;
		}

		$this->registry = new OutputRegistry();
		( new HeadOutput( $this->registry ) )->register();
		( new LanguageAlternates() )->register();
		( new GraphOutput( $this->registry ) )->register();
		( new SitemapController() )->register();
			( new IndexNow() )->register();
		( new RedirectController() )->register();
		( new NotFoundMonitor() )->register();
		( new AdvancedFeatures() )->register();
		( new YoastParityFeatures() )->register();
			( new BreadcrumbEngine() )->register();
			( new TraceIntegrity() )->register();
		$this->register_cache_invalidation();
		if ( is_admin() ) {
			( new DashboardPage( $this->registry, new JNewsAdapter() ) )->register();
			( new SettingsPage() )->register();
			( new DiagnosticsPage( $this->registry, new JNewsAdapter() ) )->register();
			( new ImportExport() )->register();
		}

		do_action( 'rankhigh_seo_loaded', $this );
	}

	/** Invalidate derived sitemap payloads when content or settings change. */
	private function register_cache_invalidation() {
		$invalidate = static function () {
			$epoch = (int) get_option( 'rankhigh_seo_cache_epoch', 1 );
			update_option( 'rankhigh_seo_cache_epoch', $epoch + 1, false );
		};
		add_action( 'save_post', $invalidate, 20 );
		add_action( 'deleted_post', $invalidate, 20 );
		foreach ( array( 'rankhigh_seo_news_enabled', 'rankhigh_seo_news_window', 'rankhigh_seo_news_post_types', 'rankhigh_seo_news_max_urls', 'rankhigh_seo_news_exclude_ids', 'rankhigh_seo_news_exclude_categories', 'rankhigh_seo_news_keywords', 'rankhigh_seo_news_genre' ) as $setting ) { add_action( 'update_option_' . $setting, $invalidate, 20 ); }
			add_action( 'update_option_rankhigh_seo_image_sitemap', $invalidate, 20 );
			add_action( 'update_option_rankhigh_image_license_url', $invalidate, 20 );
		add_action( 'update_option_rankhigh_seo_video_sitemap', $invalidate, 20 );
		add_action( 'update_option_rankhigh_seo_publisher_name', $invalidate, 20 );
		add_action( 'update_option_rankhigh_seo_publisher_logo', $invalidate, 20 );
		add_action( 'update_option_rankhigh_seo_publisher_type', $invalidate, 20 );
			foreach ( array( 'rankhigh_primary_url', 'rankhigh_media_host', 'rankhigh_cdn_enabled', 'rankhigh_cdn_host', 'rankhigh_video_host', 'rankhigh_api_host', 'rankhigh_publication_short_name', 'rankhigh_default_language', 'rankhigh_indexnow_enabled', 'rankhigh_indexnow_key', 'rankhigh_indexnow_key_location', 'rankhigh_indexnow_post_types', 'rankhigh_seo_multilingual_enabled', 'rankhigh_seo_hreflang_map', 'rankhigh_seo_x_default_url', 'rankhigh_default_locale', 'rankhigh_timezone', 'rankhigh_country', 'rankhigh_copyright', 'rankhigh_contact', 'rankhigh_social_profiles', 'rankhigh_author_mode', 'rankhigh_seo_title_separator', 'rankhigh_seo_default_robots', 'rankhigh_seo_title_template_home', 'rankhigh_seo_title_template_post', 'rankhigh_seo_title_template_page', 'rankhigh_seo_title_template_archive' ) as $setting ) { add_action( 'update_option_' . $setting, $invalidate, 20 ); }
		add_action( 'update_option_rankhigh_seo_redirects', $invalidate, 20 );
		add_action( 'update_option_rankhigh_seo_404_monitor', $invalidate, 20 );
	}
}
