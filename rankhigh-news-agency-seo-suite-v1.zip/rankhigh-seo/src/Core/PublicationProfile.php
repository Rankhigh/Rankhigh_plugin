<?php
/**
 * Centralized, site-local publication and infrastructure settings.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Core;

final class PublicationProfile {
	/** @return string */
	public static function publication_name() {
		$name = get_option( 'rankhigh_seo_publication_name', '' );
		return $name ? sanitize_text_field( (string) $name ) : sanitize_text_field( (string) get_bloginfo( 'name' ) );
	}

	/** @return string */
	public static function publisher_name() {
		$name = get_option( 'rankhigh_seo_publisher_name', '' );
		return $name ? sanitize_text_field( (string) $name ) : self::publication_name();
	}

	/** @return string */
	public static function primary_url() {
		$url = get_option( 'rankhigh_primary_url', '' );
		$url = self::normalize_url( $url ? (string) $url : home_url( '/' ), true );
		return $url ? trailingslashit( $url ) : trailingslashit( self::normalize_url( home_url( '/' ), true ) );
	}

	/** Normalize a configured URL and reject local/admin destinations. */
	public static function normalize_url( $url, $base_only = false ) {
		$url = esc_url_raw( trim( (string) $url ) );
		$parts = $url ? wp_parse_url( $url ) : array();
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) { return ''; }
		$host = strtolower( (string) $parts['host'] );
		if ( in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true ) || false !== strpos( $host, '.local' ) || false !== strpos( (string) ( $parts['path'] ?? '' ), '/wp-admin' ) ) { return ''; }
		$path = $base_only ? '/' : ( isset( $parts['path'] ) ? '/' . ltrim( $parts['path'], '/' ) : '/' );
		return set_url_scheme( $parts['scheme'] . '://' . $host . $path );
	}

	/** @return array<string, string> */
	public static function social_profiles() {
		$raw = (string) get_option( 'rankhigh_social_profiles', '' );
		$profiles = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $profile ) {
			$profile = esc_url_raw( trim( $profile ) );
			if ( $profile ) {
				$profiles[] = $profile;
			}
		}
		return $profiles;
	}

	/** @param string $url @return string */
	public static function media_url( $url ) {
		$url = esc_url_raw( $url );
		if ( ! $url ) {
			return '';
		}
		$host = trim( (string) get_option( 'rankhigh_media_host', '' ) );
		if ( ! $host ) {
			return $url;
		}
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) ) {
			return $url;
		}
		$media_host = preg_replace( '#^https?://#i', '', $host );
		$media_host = trim( (string) $media_host, '/' );
		if ( ! $media_host || in_array( strtolower( $media_host ), array( 'localhost', '127.0.0.1', '::1' ), true ) ) { return $url; }
		return $media_host ? set_url_scheme( 'https://' . $media_host . ( isset( $parts['path'] ) ? $parts['path'] : '/' ) . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' ) ) : $url;
	}

	/** @param string $url @return string */
	public static function cdn_url( $url ) {
		$url = esc_url_raw( $url );
		if ( ! $url || ! get_option( 'rankhigh_cdn_enabled', false ) ) {
			return $url;
		}
		$host = trim( (string) get_option( 'rankhigh_cdn_host', '' ) );
		if ( ! $host ) {
			return $url;
		}
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) ) {
			return $url;
		}
		$cdn_host = trim( (string) preg_replace( '#^https?://#i', '', $host ), '/' );
		if ( ! $cdn_host || in_array( strtolower( $cdn_host ), array( 'localhost', '127.0.0.1', '::1' ), true ) ) { return $url; }
		return $cdn_host ? set_url_scheme( 'https://' . $cdn_host . ( isset( $parts['path'] ) ? $parts['path'] : '/' ) . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' ) ) : $url;
	}

	/** @param string $url @return string */
	public static function asset_url( $url ) {
		return self::cdn_url( self::media_url( $url ) );
	}
}
