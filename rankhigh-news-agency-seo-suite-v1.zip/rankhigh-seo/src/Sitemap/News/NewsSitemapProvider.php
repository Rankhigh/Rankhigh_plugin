<?php
namespace RankHighSEO\Sitemap\News;

use RankHighSEO\Sitemap\Providers\SitemapProviderInterface;
use RankHighSEO\Sitemap\Engine\SitemapRenderer;
use RankHighSEO\Core\PublicationProfile;
use RankHighSEO\Meta\PostMeta;

final class NewsSitemapProvider implements SitemapProviderInterface {
	public function get_name() { return 'News'; }
	public function get_slug() { return 'news'; }
	public function is_enabled() { return (bool) get_option( 'rankhigh_seo_news_enabled', true ); }
	public function get_shard_count() { return 1; }

	private function post_types() {
		$out = array();
		foreach ( preg_split( '/[\s,]+/', (string) get_option( 'rankhigh_seo_news_post_types', 'post' ), -1, PREG_SPLIT_NO_EMPTY ) as $type ) {
			$type = sanitize_key( $type ); $obj = get_post_type_object( $type );
			if ( $obj && $obj->public && $obj->publicly_queryable ) { $out[] = $type; }
		}
		return array_values( array_unique( $out ? $out : array( 'post' ) ) );
	}

	private function ids( $option ) {
		$ids = array();
		foreach ( preg_split( '/[\s,]+/', (string) get_option( $option, '' ), -1, PREG_SPLIT_NO_EMPTY ) as $value ) { if ( absint( $value ) ) { $ids[] = absint( $value ); } }
		return array_values( array_unique( $ids ) );
	}

	private function keywords( $post_id ) {
		if ( ! get_option( 'rankhigh_seo_news_keywords', true ) ) { return array(); }
		$values = array();
		$focus = get_post_meta( $post_id, PostMeta::FOCUS_KEYWORD, true ); if ( $focus ) { $values[] = $focus; }
		$tags = get_the_tags( $post_id ); if ( is_array( $tags ) ) { $values = array_merge( $values, wp_list_pluck( $tags, 'name' ) ); }
		$categories = get_the_category( $post_id ); if ( is_array( $categories ) ) { $values = array_merge( $values, wp_list_pluck( $categories, 'name' ) ); }
		$values = array_values( array_unique( array_filter( array_map( 'wp_strip_all_tags', $values ) ) ) );
		return array_slice( $values, 0, 10 );
	}

	public function render_shard( $shard ) {
		$hours = max( 1, min( 168, (int) get_option( 'rankhigh_seo_news_window', 48 ) ) );
		$limit = max( 1, min( 1000, (int) get_option( 'rankhigh_seo_news_max_urls', 1000 ) ) );
		$args = array( 'post_type' => $this->post_types(), 'post_status' => 'publish', 'posts_per_page' => $limit, 'no_found_rows' => true, 'ignore_sticky_posts' => true, 'orderby' => 'date', 'order' => 'DESC', 'date_query' => array( array( 'after' => $hours . ' hours ago', 'inclusive' => true ) ), 'fields' => 'ids' );
		$excluded_ids = $this->ids( 'rankhigh_seo_news_exclude_ids' ); $excluded_categories = $this->ids( 'rankhigh_seo_news_exclude_categories' );
		if ( $excluded_ids ) { $args['post__not_in'] = $excluded_ids; } if ( $excluded_categories ) { $args['category__not_in'] = $excluded_categories; }
		$query = new \WP_Query( $args ); $entries = array();
		$language = substr( preg_replace( '/[^a-zA-Z-]/', '', sanitize_text_field( (string) get_option( 'rankhigh_default_language', substr( (string) get_locale(), 0, 2 ) ) ) ), 0, 8 ) ?: 'en';
		$name = PublicationProfile::publication_name(); $genre = sanitize_text_field( (string) get_option( 'rankhigh_seo_news_genre', '' ) );
		foreach ( $query->posts as $post_id ) {
			if ( '0' === (string) get_post_meta( $post_id, PostMeta::NEWS_ELIGIBLE, true ) ) { continue; }
			$robots = strtolower( (string) get_post_meta( $post_id, PostMeta::ROBOTS, true ) ); $url = get_permalink( $post_id ); $title = wp_strip_all_tags( get_the_title( $post_id ) );
			if ( false !== strpos( $robots, 'noindex' ) || ! $url || ! $title ) { continue; }
			$news = '<news:news><news:publication><news:name>' . esc_xml( $name ) . '</news:name><news:language>' . esc_xml( $language ) . '</news:language></news:publication>';
			$news .= '<news:publication_date>' . esc_xml( get_post_time( DATE_W3C, true, $post_id ) ) . '</news:publication_date><news:title>' . esc_xml( $title ) . '</news:title>';
			if ( $genre ) { $news .= '<news:genres>' . esc_xml( $genre ) . '</news:genres>'; }
			$keywords = $this->keywords( $post_id ); if ( $keywords ) { $news .= '<news:keywords>' . esc_xml( implode( ', ', $keywords ) ) . '</news:keywords>'; }
			$news .= '</news:news>';
			$entries[] = SitemapRenderer::url( $url, get_post_modified_time( DATE_W3C, true, $post_id ), $news );
		}
		return SitemapRenderer::urlset( $entries, array( 'news' => 'http://www.google.com/schemas/sitemap-news/0.9' ) );
	}
}
