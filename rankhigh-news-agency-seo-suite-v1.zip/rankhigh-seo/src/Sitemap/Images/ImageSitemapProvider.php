<?php
namespace RankHighSEO\Sitemap\Images;

use RankHighSEO\Sitemap\Providers\AbstractPostProvider;
use RankHighSEO\Sitemap\Engine\SitemapRenderer;

final class ImageSitemapProvider extends AbstractPostProvider {
	protected $slug = 'image'; protected $name = 'Images'; protected $post_types = array( 'post' );
	public function is_enabled() { return (bool) get_option( 'rankhigh_seo_image_sitemap', true ); }
	protected function extra( $post_id ) {
		$ids = array(); $featured = get_post_thumbnail_id( $post_id ); if ( $featured ) { $ids[] = $featured; }
		foreach ( get_attached_media( 'image', $post_id ) as $attachment ) { $ids[] = $attachment->ID; }
		$images = array(); $license = esc_url_raw( (string) get_option( 'rankhigh_image_license_url', '' ) );
		foreach ( array_unique( $ids ) as $id ) {
			$url = wp_get_attachment_image_url( $id, 'full' ); if ( ! $url ) { continue; }
			$attachment = get_post( $id ); $title = get_the_title( $id ); $caption = $attachment instanceof \WP_Post ? ( $attachment->post_excerpt ?: $attachment->post_content ) : '';
			$images[] = SitemapRenderer::image( $url, $title, wp_trim_words( wp_strip_all_tags( $caption ), 40, '' ), '', $license );
		}
		return implode( '', array_slice( $images, 0, 20 ) );
	}
	protected function namespaces() { return array( 'image' => 'http://www.google.com/schemas/sitemap-image/1.1' ); }
}
