<?php
namespace RankHighSEO\Sitemap\Video;

use RankHighSEO\Sitemap\Providers\AbstractPostProvider;

final class VideoSitemapProvider extends AbstractPostProvider {
	protected $slug = 'video'; protected $name = 'Videos'; protected $post_types = array( 'post' );
	public function is_enabled() { return (bool) get_option( 'rankhigh_seo_video_sitemap', true ); }
	protected function extra( $post_id ) {
		$content = (string) get_post_field( 'post_content', $post_id ); preg_match_all( '/https?:\\/\\/[^\\s"\'<>]+\\.(?:mp4|webm|mov)(?:\\?[^\\s"\'<>]+)?/i', $content, $matches );
		$urls = array_unique( $matches[0] ); foreach ( get_attached_media( 'video', $post_id ) as $attachment ) { $url = wp_get_attachment_url( $attachment->ID ); if ( $url ) { $urls[] = $url; } }
		$thumb = get_the_post_thumbnail_url( $post_id, 'full' ); if ( ! $thumb ) { return ''; } $xml = '';
		foreach ( array_slice( array_filter( array_unique( $urls ) ), 0, 10 ) as $video_url ) { $xml .= '<video:video><video:thumbnail_loc>' . esc_xml( esc_url_raw( $thumb ) ) . '</video:thumbnail_loc><video:title>' . esc_xml( wp_strip_all_tags( get_the_title( $post_id ) ) ) . '</video:title><video:description>' . esc_xml( wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post_id ) ), 30 ) ) . '</video:description><video:content_loc>' . esc_xml( esc_url_raw( $video_url ) ) . '</video:content_loc><video:publication_date>' . esc_xml( get_post_time( DATE_W3C, true, $post_id ) ) . '</video:publication_date></video:video>'; }
		return $xml;
	}
	protected function namespaces() { return array( 'video' => 'http://www.google.com/schemas/sitemap-video/1.1' ); }
}
