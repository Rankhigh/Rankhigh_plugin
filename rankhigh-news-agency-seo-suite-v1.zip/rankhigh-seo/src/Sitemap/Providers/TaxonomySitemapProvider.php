<?php
namespace RankHighSEO\Sitemap\Providers;

use RankHighSEO\Sitemap\Engine\SitemapRenderer;

final class TaxonomySitemapProvider implements SitemapProviderInterface {
	const SHARD_SIZE = 45000;
	public function get_name() { return 'Taxonomies'; }
	public function get_slug() { return 'taxonomy'; }
	public function is_enabled() { return (bool) get_option( 'rankhigh_sitemap_taxonomies_enabled', true ); }
	private function taxonomies() {
		$out = array();
		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $taxonomy ) {
			if ( $taxonomy->publicly_queryable ) { $out[] = $taxonomy->name; }
		}
		return $out;
	}
	public function get_shard_count() {
		$count = 0;
		foreach ( $this->taxonomies() as $taxonomy ) {
			$count += (int) wp_count_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => true ) );
		}
		return max( 1, (int) ceil( $count / self::SHARD_SIZE ) );
	}
	public function render_shard( $shard ) {
		$offset = ( max( 1, absint( $shard ) ) - 1 ) * self::SHARD_SIZE;
		$terms = get_terms( array( 'taxonomy' => $this->taxonomies(), 'hide_empty' => true, 'number' => self::SHARD_SIZE, 'offset' => $offset ) );
		$entries = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$url = get_term_link( $term );
				if ( is_wp_error( $url ) || ! $url || false !== strpos( strtolower( (string) get_term_meta( $term->term_id, '_rankhigh_seo_robots', true ) ), 'noindex' ) ) { continue; }
				$entries[] = SitemapRenderer::url( $url, ! empty( $term->term_id ) ? get_term_meta( $term->term_id, '_rankhigh_last_modified', true ) : '' );
			}
		}
		return SitemapRenderer::urlset( $entries );
	}
}
