<?php
namespace RankHighSEO\Sitemap\Providers;

use RankHighSEO\Sitemap\Engine\SitemapRenderer;

final class AttachmentSitemapProvider implements SitemapProviderInterface {
	const SHARD_SIZE = 45000;
	public function get_name() { return 'Attachments'; }
	public function get_slug() { return 'attachment'; }
	public function is_enabled() { return (bool) get_option( 'rankhigh_sitemap_attachments_enabled', false ); }
	public function get_shard_count() {
		$counts = wp_count_posts( 'attachment' );
		$total = $counts && isset( $counts->inherit ) ? (int) $counts->inherit : 0;
		return max( 1, (int) ceil( $total / self::SHARD_SIZE ) );
	}
	public function render_shard( $shard ) {
		$query = new \WP_Query( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => self::SHARD_SIZE, 'offset' => ( max( 1, absint( $shard ) ) - 1 ) * self::SHARD_SIZE, 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true, 'fields' => 'ids' ) );
		$entries = array();
		foreach ( $query->posts as $id ) {
			$url = wp_get_attachment_url( $id );
			if ( $url ) { $entries[] = SitemapRenderer::url( $url, get_post_modified_time( DATE_W3C, true, $id ) ); }
		}
		return SitemapRenderer::urlset( $entries );
	}
}
