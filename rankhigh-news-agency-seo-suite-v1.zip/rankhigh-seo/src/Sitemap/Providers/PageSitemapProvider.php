<?php
namespace RankHighSEO\Sitemap\Providers;

final class PageSitemapProvider extends AbstractPostProvider {
	protected $slug = 'page';
	protected $name = 'Pages';
	protected $post_types = array( 'page' );
	public function is_enabled() { return (bool) get_option( 'rankhigh_sitemap_pages_enabled', true ); }
}
