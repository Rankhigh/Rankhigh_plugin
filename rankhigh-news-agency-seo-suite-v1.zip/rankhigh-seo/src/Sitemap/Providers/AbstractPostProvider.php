<?php
namespace RankHighSEO\Sitemap\Providers;

use RankHighSEO\Sitemap\Engine\SitemapRenderer;

abstract class AbstractPostProvider implements SitemapProviderInterface {
	const SHARD_SIZE = 45000;
	protected $post_types = array();
	protected $slug = 'post';
	protected $name = 'Posts';

	public function get_name() { return $this->name; }
	public function get_slug() { return $this->slug; }
	public function is_enabled() { return true; }
	public function get_shard_count() {
		$total = 0;
		foreach ( $this->post_types as $type ) {
			$counts = wp_count_posts( $type );
			$total += $counts && isset( $counts->publish ) ? (int) $counts->publish : 0;
		}
		return max( 1, (int) ceil( $total / self::SHARD_SIZE ) );
	}
	public function render_shard( $shard ) {
		$offset = ( max( 1, absint( $shard ) ) - 1 ) * self::SHARD_SIZE;
		$query = new \WP_Query( array(
			'post_type' => $this->post_types,
			'post_status' => 'publish',
			'posts_per_page' => self::SHARD_SIZE,
			'offset' => $offset,
			'orderby' => 'ID',
			'order' => 'ASC',
			'no_found_rows' => true,
			'ignore_sticky_posts' => true,
			'fields' => 'ids',
		) );
		$entries = array();
		foreach ( $query->posts as $post_id ) {
			if ( ! $this->is_indexable( $post_id ) ) { continue; }
			$url = get_permalink( $post_id );
			if ( ! $url || $this->is_bad_url( $url ) ) { continue; }
			$entries[] = SitemapRenderer::url( $url, get_post_modified_time( DATE_W3C, true, $post_id ), $this->extra( $post_id ) );
		}
		return SitemapRenderer::urlset( $entries, $this->namespaces() );
	}
	protected function is_indexable( $post_id ) {
		$robots = strtolower( (string) get_post_meta( $post_id, '_rankhigh_seo_robots', true ) );
		return false === strpos( $robots, 'noindex' ) && ! wp_is_post_revision( $post_id ) && ! wp_is_post_autosave( $post_id );
	}
	protected function is_bad_url( $url ) {
		$parsed = wp_parse_url( $url );
		$home = wp_parse_url( home_url( '/' ) );
		return empty( $parsed['host'] ) || empty( $home['host'] ) || strtolower( $parsed['host'] ) !== strtolower( $home['host'] );
	}
	protected function extra( $post_id ) { return ''; }
	protected function namespaces() { return array(); }
}
