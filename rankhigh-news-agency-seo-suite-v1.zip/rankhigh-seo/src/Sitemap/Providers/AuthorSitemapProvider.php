<?php
namespace RankHighSEO\Sitemap\Providers;

use RankHighSEO\Sitemap\Engine\SitemapRenderer;

final class AuthorSitemapProvider implements SitemapProviderInterface {
	const SHARD_SIZE = 45000;
	public function get_name() { return 'Authors'; }
	public function get_slug() { return 'author'; }
	public function is_enabled() { return (bool) get_option( 'rankhigh_sitemap_authors_enabled', true ); }
	public function get_shard_count() { return max( 1, (int) ceil( (int) count_users()['total_users'] / self::SHARD_SIZE ) ); }
	public function render_shard( $shard ) {
		$users = get_users( array( 'number' => self::SHARD_SIZE, 'offset' => ( max( 1, absint( $shard ) ) - 1 ) * self::SHARD_SIZE, 'who' => 'authors', 'fields' => array( 'ID', 'user_nicename' ) ) );
		$entries = array();
		foreach ( $users as $user ) {
			$url = get_author_posts_url( $user->ID, $user->user_nicename );
			if ( $url ) { $entries[] = SitemapRenderer::url( $url ); }
		}
		return SitemapRenderer::urlset( $entries );
	}
}
