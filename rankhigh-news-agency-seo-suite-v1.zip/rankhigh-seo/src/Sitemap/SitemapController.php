<?php
namespace RankHighSEO\Sitemap;

use RankHighSEO\Sitemap\Engine\SitemapEngine;

final class SitemapController {
	private $engine;
	public function __construct() { $this->engine = new SitemapEngine(); }
	public function register() {
		add_action( 'init', array( $this, 'rewrite' ) );
		add_action( 'template_redirect', array( $this, 'render' ) );
		add_filter( 'wp_sitemaps_enabled', '__return_false', 20 );
	}
	public function rewrite() {
		add_rewrite_tag( '%rankhigh_sitemap%', '([^&]+)' );
		add_rewrite_rule( '^rankhigh-sitemap\.xml$', 'index.php?rankhigh_sitemap=index', 'top' );
		add_rewrite_rule( '^rankhigh-([a-z-]+)-sitemap-([0-9]+)\.xml$', 'index.php?rankhigh_sitemap=$matches[1]&rankhigh_sitemap_shard=$matches[2]', 'top' );
		add_rewrite_rule( '^rankhigh-([a-z-]+)-sitemap\.xml$', 'index.php?rankhigh_sitemap=$matches[1]&rankhigh_sitemap_shard=1', 'top' );
		add_rewrite_tag( '%rankhigh_sitemap_shard%', '([0-9]+)' );
	}
	public function render() {
		$slug = sanitize_key( (string) get_query_var( 'rankhigh_sitemap' ) );
		if ( ! $slug ) { return; }
		$xml = 'index' === $slug ? $this->engine->index() : $this->engine->render( $slug, max( 1, absint( get_query_var( 'rankhigh_sitemap_shard', 1 ) ) ) );
		if ( '' === $xml ) { return; }
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=' . get_bloginfo( 'charset' ) );
		header( 'X-Robots-Tag: noindex' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . $xml; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}
	public function engine() { return $this->engine; }
}
