<?php
namespace RankHighSEO\Sitemap\Engine;

final class SitemapLock {
	const TTL = 30;

	public function acquire( $provider, $shard ) {
		$key = 'rankhigh_sitemap_lock_' . sanitize_key( $provider ) . '_' . absint( $shard );
		if ( get_transient( $key ) ) {
			return false;
		}
		return (bool) set_transient( $key, 1, self::TTL );
	}

	public function release( $provider, $shard ) {
		delete_transient( 'rankhigh_sitemap_lock_' . sanitize_key( $provider ) . '_' . absint( $shard ) );
	}
}
