<?php
namespace RankHighSEO\Sitemap\Engine;

final class SitemapCache {
	const TTL = 3600;

	public function key( $provider, $shard ) {
		$epoch = (int) get_option( 'rankhigh_seo_cache_epoch', 1 );
		return 'rankhigh_sitemap_' . sanitize_key( $provider ) . '_' . absint( $shard ) . '_' . $epoch;
	}

	public function get( $provider, $shard ) {
		return get_transient( $this->key( $provider, $shard ) );
	}

	public function set( $provider, $shard, $xml ) {
		return set_transient( $this->key( $provider, $shard ), $xml, self::TTL );
	}

	public function clear() {
		$epoch = (int) get_option( 'rankhigh_seo_cache_epoch', 1 );
		update_option( 'rankhigh_seo_cache_epoch', $epoch + 1, false );
		update_option( 'rankhigh_seo_last_invalidation', time(), false );
	}
}
