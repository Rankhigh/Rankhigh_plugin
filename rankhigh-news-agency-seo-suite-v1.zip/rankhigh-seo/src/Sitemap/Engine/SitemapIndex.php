<?php
namespace RankHighSEO\Sitemap\Engine;

final class SitemapIndex {
	public function render( $providers ) {
		$items = array();
		foreach ( $providers as $provider ) {
			if ( ! $provider->is_enabled() ) {
				continue;
			}
			$count = $provider->get_shard_count();
			for ( $shard = 1; $shard <= $count; $shard++ ) {
				$url = home_url( '/rankhigh-' . $provider->get_slug() . '-sitemap-' . $shard . '.xml' );
				$items[] = '<sitemap><loc>' . esc_xml( esc_url_raw( $url ) ) . '</loc></sitemap>';
			}
		}
		return '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . implode( '', $items ) . '</sitemapindex>';
	}
}
