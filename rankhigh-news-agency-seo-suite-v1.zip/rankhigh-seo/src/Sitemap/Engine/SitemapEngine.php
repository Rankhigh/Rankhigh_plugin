<?php
namespace RankHighSEO\Sitemap\Engine;

use RankHighSEO\Sitemap\Providers\SitemapProviderInterface;
use RankHighSEO\Sitemap\Providers\PostSitemapProvider;
use RankHighSEO\Sitemap\Providers\PageSitemapProvider;
use RankHighSEO\Sitemap\Providers\CPTSitemapProvider;
use RankHighSEO\Sitemap\Providers\TaxonomySitemapProvider;
use RankHighSEO\Sitemap\Providers\AuthorSitemapProvider;
use RankHighSEO\Sitemap\Providers\AttachmentSitemapProvider;
use RankHighSEO\Sitemap\News\NewsSitemapProvider;
use RankHighSEO\Sitemap\Images\ImageSitemapProvider;
use RankHighSEO\Sitemap\Video\VideoSitemapProvider;

final class SitemapEngine {
	private $cache;
	private $lock;
	private $providers = array();
	public function __construct() {
		$this->cache = new SitemapCache();
		$this->lock = new SitemapLock();
		$this->providers = array( new PostSitemapProvider(), new PageSitemapProvider(), new CPTSitemapProvider(), new TaxonomySitemapProvider(), new AuthorSitemapProvider(), new AttachmentSitemapProvider(), new NewsSitemapProvider(), new ImageSitemapProvider(), new VideoSitemapProvider() );
		$this->providers = apply_filters( 'rankhigh_sitemap_providers', $this->providers );
	}
	public function providers() { return array_filter( $this->providers, function ( $provider ) { return $provider instanceof SitemapProviderInterface; } ); }
	public function provider( $slug ) { foreach ( $this->providers() as $provider ) { if ( $provider->get_slug() === $slug ) { return $provider; } } return null; }
	public function index() { return ( new SitemapIndex() )->render( $this->providers() ); }
	public function render( $slug, $shard = 1 ) {
		$provider = $this->provider( $slug );
		if ( ! $provider || ! $provider->is_enabled() || absint( $shard ) < 1 || absint( $shard ) > $provider->get_shard_count() ) { return ''; }
		$shard = absint( $shard );
		$cached = $this->cache->get( $slug, $shard );
		if ( false !== $cached && '' !== $cached ) { return $cached; }
		if ( ! $this->lock->acquire( $slug, $shard ) ) {
			$stale = get_transient( 'rankhigh_sitemap_stale_' . sanitize_key( $slug ) . '_' . $shard );
			return false !== $stale ? $stale : $provider->render_shard( $shard );
		}
		try {
			$xml = $provider->render_shard( $shard );
			if ( $xml ) { $this->cache->set( $slug, $shard, $xml ); set_transient( 'rankhigh_sitemap_stale_' . sanitize_key( $slug ) . '_' . $shard, $xml, DAY_IN_SECONDS ); }
			return $xml;
		} finally { $this->lock->release( $slug, $shard ); }
	}
	public function clear_cache() { $this->cache->clear(); }
}
