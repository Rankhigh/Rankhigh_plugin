<?php
/**
 * RankHigh SEO administrator dashboard.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Admin;

use RankHighSEO\Compatibility\JNewsAdapter;
use RankHighSEO\Core\OutputRegistry;

final class DashboardPage {
	/** @var OutputRegistry */
	private $registry;

	/** @var JNewsAdapter */
	private $jnews;

	public function __construct( OutputRegistry $registry, JNewsAdapter $jnews ) {
		$this->registry = $registry;
		$this->jnews    = $jnews;
	}

	/** Register the dashboard menu. */
	public function register() {
		add_menu_page(
			__( 'RankHigh SEO', 'rankhigh-seo' ),
			__( 'RankHigh SEO', 'rankhigh-seo' ),
			'manage_options',
			'rankhigh-seo-dashboard',
			array( $this, 'render' ),
			'dashicons-shield-alt',
			58
		);
	}

	/** Render a concise, proficiency-oriented overview. */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$checks = $this->checks();
		$passed = count( array_filter( $checks, static function ( $check ) { return 'PASS' === $check['status']; } ) );
		$total  = count( $checks );
		$score  = $total ? (int) round( ( $passed / $total ) * 100 ) : 0;
		$level  = $this->level( $score );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'RankHigh SEO dashboard', 'rankhigh-seo' ); ?></h1>
			<p><?php esc_html_e( 'A focused overview of your technical SEO setup. Use the learning path to build confidence without changing your theme presentation.', 'rankhigh-seo' ); ?></p>
			<div class="rankhigh-seo-dashboard-grid" style="display:grid;grid-template-columns:minmax(260px,1fr) minmax(320px,2fr);gap:20px;max-width:1100px;margin-top:20px;">
				<div class="postbox" style="margin:0;padding:24px;text-align:center;">
					<p style="font-size:13px;text-transform:uppercase;letter-spacing:.08em;margin:0 0 8px;color:#50575e;"><?php esc_html_e( 'SEO proficiency', 'rankhigh-seo' ); ?></p>
					<p style="font-size:56px;line-height:1;margin:10px 0;font-weight:700;color:#2271b1;"><?php echo esc_html( $score ); ?><span style="font-size:24px;">%</span></p>
					<h2 style="margin:8px 0;"><?php echo esc_html( $level ); ?></h2>
					<p style="margin-bottom:0;color:#50575e;"><?php echo esc_html( sprintf( /* translators: 1: passed checks, 2: total checks. */ __( '%1$d of %2$d foundation checks pass.', 'rankhigh-seo' ), $passed, $total ) ); ?></p>
				</div>
				<div class="postbox" style="margin:0;padding:24px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Guided learning path', 'rankhigh-seo' ); ?></h2>
					<ol style="margin-bottom:0;">
						<li><strong><?php esc_html_e( 'Foundation', 'rankhigh-seo' ); ?></strong> — <?php esc_html_e( 'Keep one owner for titles, descriptions, canonicals, robots, social tags, and schema.', 'rankhigh-seo' ); ?></li>
						<li><strong><?php esc_html_e( 'News readiness', 'rankhigh-seo' ); ?></strong> — <?php esc_html_e( 'Review the freshness window and confirm publisher and author information.', 'rankhigh-seo' ); ?></li>
						<li><strong><?php esc_html_e( 'Maintenance', 'rankhigh-seo' ); ?></strong> — <?php esc_html_e( 'Use diagnostics after theme or SEO plugin changes, then review redirects and 404s.', 'rankhigh-seo' ); ?></li>
					</ol>
				</div>
			</div>
			<h2><?php esc_html_e( 'Technical health', 'rankhigh-seo' ); ?></h2>
			<table class="widefat striped" style="max-width:1100px;"><thead><tr><th><?php esc_html_e( 'Area', 'rankhigh-seo' ); ?></th><th><?php esc_html_e( 'Status', 'rankhigh-seo' ); ?></th><th><?php esc_html_e( 'What to do', 'rankhigh-seo' ); ?></th></tr></thead><tbody>
			<?php foreach ( $checks as $check ) : ?>
				<tr><td><strong><?php echo esc_html( $check['label'] ); ?></strong></td><td><span class="notice-<?php echo 'PASS' === $check['status'] ? 'success' : 'warning'; ?>" style="display:inline-block;padding:3px 8px;"><?php echo esc_html( $check['status'] ); ?></span></td><td><?php echo esc_html( $check['message'] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
			<p style="margin-top:18px;"><a class="button button-primary" href="<?php echo esc_url( admin_url( 'options-general.php?page=rankhigh-seo-diagnostics' ) ); ?>"><?php esc_html_e( 'Open full diagnostics', 'rankhigh-seo' ); ?></a> <a class="button" href="<?php echo esc_url( admin_url( 'options-general.php?page=rankhigh-seo' ) ); ?>"><?php esc_html_e( 'Configure RankHigh SEO', 'rankhigh-seo' ); ?></a></p>
		</div>
		<?php
	}

	/** @return array<int,array<string,string>> */
	private function checks() {
		$checks = array();
		foreach ( array( 'title', 'description', 'canonical', 'robots', 'og', 'twitter', 'jsonld' ) as $key ) {
			$checks[] = array(
				'label'   => ucwords( 'jsonld' === $key ? 'JSON-LD graph' : $key ),
				'status'  => $this->registry->has( $key ) ? 'PASS' : 'WARNING',
				'message' => $this->registry->has( $key ) ? __( 'RankHigh has registered this output slot.', 'rankhigh-seo' ) : __( 'Visit diagnostics to inspect ownership and compatibility.', 'rankhigh-seo' ),
			);
		}
		$compatibility = $this->jnews->diagnostics();
		$checks[]      = array( 'label' => __( 'JNews compatibility', 'rankhigh-seo' ), 'status' => $compatibility['status'], 'message' => $compatibility['message'] );
		return $checks;
	}

	/** @return string */
	private function level( $score ) {
		if ( $score >= 90 ) {
			return __( 'SEO steward', 'rankhigh-seo' );
		}
		if ( $score >= 70 ) {
			return __( 'Confident publisher', 'rankhigh-seo' );
		}
		if ( $score >= 40 ) {
			return __( 'Growing practitioner', 'rankhigh-seo' );
		}
		return __( 'Getting started', 'rankhigh-seo' );
	}
}
