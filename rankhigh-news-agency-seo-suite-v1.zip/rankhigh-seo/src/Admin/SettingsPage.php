<?php
/**
 * Complete, site-local RankHigh SEO settings surface.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Admin;

final class SettingsPage {
	/** Register admin hooks. */
	public function register() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'settings' ) );
	}

	/** Register the settings page. */
	public function menu() {
		add_options_page( __( 'RankHigh SEO', 'rankhigh-seo' ), __( 'RankHigh SEO', 'rankhigh-seo' ), 'manage_options', 'rankhigh-seo', array( $this, 'page' ) );
	}

	/** Register and sanitize every setting used by this site. */
	public function settings() {
		register_setting( 'rankhigh_seo', 'rankhigh_seo_news_enabled', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) );
			register_setting( 'rankhigh_seo', 'rankhigh_seo_news_window', array( 'type' => 'integer', 'sanitize_callback' => array( $this, 'sanitize_window' ), 'default' => 48 ) );
			register_setting( 'rankhigh_seo', 'rankhigh_seo_publisher_type', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_publisher_type' ), 'default' => 'NewsMediaOrganization' ) );
			register_setting( 'rankhigh_seo', 'rankhigh_seo_title_separator', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '|' ) );
			register_setting( 'rankhigh_seo', 'rankhigh_seo_default_robots', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_robots' ), 'default' => 'index,follow' ) );
			foreach ( array( 'home' => '%%sitename%% %%page%%', 'post' => '%%title%% %%sep%% %%sitename%% %%page%%', 'page' => '%%title%% %%sep%% %%sitename%%', 'archive' => '%%title%% %%sep%% %%sitename%%' ) as $context => $default ) {
				register_setting( 'rankhigh_seo', 'rankhigh_seo_title_template_' . $context, array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_template' ), 'default' => $default ) );
			}
			register_setting( 'rankhigh_seo', 'rankhigh_seo_news_max_urls', array( 'type' => 'integer', 'sanitize_callback' => array( $this, 'sanitize_max_urls' ), 'default' => 1000 ) );
			register_setting( 'rankhigh_seo', 'rankhigh_seo_news_keywords', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) );
			register_setting( 'rankhigh_seo', 'rankhigh_sitemap_post_types', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_post_types' ), 'default' => 'post' ) );
			foreach ( array( 'rankhigh_sitemap_pages_enabled', 'rankhigh_sitemap_cpt_enabled', 'rankhigh_sitemap_taxonomies_enabled', 'rankhigh_sitemap_authors_enabled', 'rankhigh_sitemap_attachments_enabled' ) as $field ) { register_setting( 'rankhigh_seo', $field, array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) ); }
			register_setting( 'rankhigh_seo', 'rankhigh_breadcrumbs_enabled', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) );
			register_setting( 'rankhigh_seo', 'rankhigh_breadcrumbs_separator', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '→' ) );
		register_setting( 'rankhigh_seo', 'rankhigh_indexnow_enabled', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ) );
		register_setting( 'rankhigh_seo', 'rankhigh_seo_multilingual_enabled', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) );
		register_setting( 'rankhigh_seo', 'rankhigh_cdn_enabled', array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ) );
		foreach ( array( 'rankhigh_seo_publication_name', 'rankhigh_indexnow_key', 'rankhigh_indexnow_post_types', 'rankhigh_seo_hreflang_map', 'rankhigh_seo_news_post_types', 'rankhigh_seo_news_exclude_ids', 'rankhigh_seo_news_exclude_categories', 'rankhigh_seo_news_genre', 'rankhigh_seo_publisher_name', 'rankhigh_publication_short_name', 'rankhigh_default_language', 'rankhigh_default_locale', 'rankhigh_timezone', 'rankhigh_country', 'rankhigh_copyright', 'rankhigh_contact', 'rankhigh_social_profiles', 'rankhigh_author_mode' ) as $field ) {
			register_setting( 'rankhigh_seo', $field, array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => '' ) );
		}
			foreach ( array( 'rankhigh_seo_x_default_url', 'rankhigh_indexnow_key_location', 'rankhigh_primary_url', 'rankhigh_media_host', 'rankhigh_cdn_host', 'rankhigh_video_host', 'rankhigh_api_host', 'rankhigh_seo_publisher_logo' ) as $field ) {
				register_setting( 'rankhigh_seo', $field, array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_public_url' ), 'default' => '' ) );
		}
			foreach ( array( 'rankhigh_seo_image_sitemap', 'rankhigh_seo_video_sitemap', 'rankhigh_seo_404_monitor' ) as $field ) {
				register_setting( 'rankhigh_seo', $field, array( 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ) );
			}
			register_setting( 'rankhigh_seo', 'rankhigh_image_license_url', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_public_url' ), 'default' => '' ) );
	}

	/** @param mixed $value @return string */
		public function sanitize_publisher_type( $value ) {
			$value = sanitize_text_field( (string) $value );
			return in_array( $value, array( 'NewsMediaOrganization', 'Organization' ), true ) ? $value : 'NewsMediaOrganization';
		}

		/** @param mixed $value @return string */
		public function sanitize_robots( $value ) {
			$value = sanitize_text_field( (string) $value );
			return ( new \RankHighSEO\Meta\MetaGenerator() )->normalize_robots( $value );
		}

		/** @param mixed $value @return string */
		public function sanitize_template( $value ) {
			$value = sanitize_text_field( (string) $value );
			return preg_replace( '/[^\p{L}\p{N}\s%_\-–—|.,:()]+/u', '', $value );
		}

		/** @param mixed $value @return int */
	public function sanitize_max_urls( $value ) {
		return min( 1000, max( 1, absint( $value ) ) );
	}

	/** @param mixed $value @return int */
		public function sanitize_window( $value ) {
		$value = absint( $value );
		update_option( 'rankhigh_seo_cache_epoch', time(), false );
		return min( 168, max( 1, $value ) );
	}

		/** @param mixed $value @return string */
		public function sanitize_public_url( $value ) {
			$url = \RankHighSEO\Core\PublicationProfile::normalize_url( $value );
			return $url ? $url : '';
		}

		/** @param mixed $value @return string */
		public function sanitize_post_types( $value ) {
			$valid = array();
			foreach ( preg_split( '/[\s,]+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY ) as $type ) { $type = sanitize_key( $type ); $object = get_post_type_object( $type ); if ( $object && $object->public && $object->publicly_queryable && 'attachment' !== $type ) { $valid[] = $type; } }
			return implode( ',', array_values( array_unique( $valid ? $valid : array( 'post' ) ) ) );
		}

		/** Render the settings form. */
		public function page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}
		$val = static function ( $key, $default = '' ) { return get_option( $key, $default ); };
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'RankHigh SEO', 'rankhigh-seo' ); ?></h1>
			<p><?php esc_html_e( 'Configure RankHigh for this WordPress site. Every site in a multisite network keeps its own publication identity and infrastructure settings.', 'rankhigh-seo' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'rankhigh_seo' ); ?>
			<h2><?php esc_html_e( 'Publication profile', 'rankhigh-seo' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th scope="row"><label for="rankhigh_seo_publication_name"><?php esc_html_e( 'Publication name', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_publication_name" name="rankhigh_seo_publication_name" type="text" value="<?php echo esc_attr( $val( 'rankhigh_seo_publication_name', get_bloginfo( 'name' ) ) ); ?>" class="regular-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_publication_short_name"><?php esc_html_e( 'Short name', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_publication_short_name" name="rankhigh_publication_short_name" type="text" value="<?php echo esc_attr( $val( 'rankhigh_publication_short_name' ) ); ?>" class="regular-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_primary_url"><?php esc_html_e( 'Primary website URL', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_primary_url" name="rankhigh_primary_url" type="url" value="<?php echo esc_attr( $val( 'rankhigh_primary_url', home_url( '/' ) ) ); ?>" class="large-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_seo_publisher_name"><?php esc_html_e( 'Publisher name', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_publisher_name" name="rankhigh_seo_publisher_name" type="text" value="<?php echo esc_attr( $val( 'rankhigh_seo_publisher_name', get_bloginfo( 'name' ) ) ); ?>" class="regular-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_seo_publisher_logo"><?php esc_html_e( 'Publisher logo URL', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_publisher_logo" name="rankhigh_seo_publisher_logo" type="url" value="<?php echo esc_attr( $val( 'rankhigh_seo_publisher_logo' ) ); ?>" class="large-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_seo_publisher_type"><?php esc_html_e( 'Publisher type', 'rankhigh-seo' ); ?></label></th><td><select id="rankhigh_seo_publisher_type" name="rankhigh_seo_publisher_type"><option value="NewsMediaOrganization" <?php selected( $val( 'rankhigh_seo_publisher_type', 'NewsMediaOrganization' ), 'NewsMediaOrganization' ); ?>><?php esc_html_e( 'News media organization', 'rankhigh-seo' ); ?></option><option value="Organization" <?php selected( $val( 'rankhigh_seo_publisher_type', 'NewsMediaOrganization' ), 'Organization' ); ?>><?php esc_html_e( 'Organization', 'rankhigh-seo' ); ?></option></select></td></tr>
				<tr><th scope="row"><label for="rankhigh_default_language"><?php esc_html_e( 'Language / locale', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_default_language" name="rankhigh_default_language" type="text" value="<?php echo esc_attr( $val( 'rankhigh_default_language', substr( (string) get_locale(), 0, 2 ) ) ); ?>" class="small-text" placeholder="en" /> <input id="rankhigh_default_locale" name="rankhigh_default_locale" type="text" value="<?php echo esc_attr( $val( 'rankhigh_default_locale', get_locale() ) ); ?>" class="small-text" placeholder="en_US" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_timezone"><?php esc_html_e( 'Timezone / country', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_timezone" name="rankhigh_timezone" type="text" value="<?php echo esc_attr( $val( 'rankhigh_timezone', wp_timezone_string() ) ); ?>" class="regular-text" placeholder="UTC" /> <input id="rankhigh_country" name="rankhigh_country" type="text" value="<?php echo esc_attr( $val( 'rankhigh_country' ) ); ?>" class="small-text" placeholder="US" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_copyright"><?php esc_html_e( 'Copyright / contact', 'rankhigh-seo' ); ?></label></th><td><textarea id="rankhigh_copyright" name="rankhigh_copyright" rows="2" class="large-text"><?php echo esc_textarea( $val( 'rankhigh_copyright' ) ); ?></textarea><textarea id="rankhigh_contact" name="rankhigh_contact" rows="2" class="large-text" placeholder="contact@example.com"><?php echo esc_textarea( $val( 'rankhigh_contact' ) ); ?></textarea></td></tr>
				<tr><th scope="row"><label for="rankhigh_social_profiles"><?php esc_html_e( 'Social profiles', 'rankhigh-seo' ); ?></label></th><td><textarea id="rankhigh_social_profiles" name="rankhigh_social_profiles" rows="4" class="large-text" placeholder="One profile URL per line"><?php echo esc_textarea( $val( 'rankhigh_social_profiles' ) ); ?></textarea></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Instant search discovery', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_indexnow_enabled" value="0" /><label><input name="rankhigh_indexnow_enabled" type="checkbox" value="1" <?php checked( $val( 'rankhigh_indexnow_enabled', false ) ); ?> /> <?php esc_html_e( 'Enable IndexNow URL submission after publishing', 'rankhigh-seo' ); ?></label><p class="description"><?php esc_html_e( 'Sends published URLs to participating search engines through a delayed, retry-safe WordPress cron task.', 'rankhigh-seo' ); ?></p></td></tr>
				<tr><th scope="row"><label for="rankhigh_indexnow_key"><?php esc_html_e( 'IndexNow key', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_indexnow_key" name="rankhigh_indexnow_key" type="text" value="<?php echo esc_attr( $val( 'rankhigh_indexnow_key' ) ); ?>" class="large-text code" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_indexnow_key_location"><?php esc_html_e( 'IndexNow key location', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_indexnow_key_location" name="rankhigh_indexnow_key_location" type="url" value="<?php echo esc_attr( $val( 'rankhigh_indexnow_key_location', home_url( '/rankhigh-indexnow-key.txt' ) ) ); ?>" class="large-text" /><p class="description"><?php esc_html_e( 'RankHigh serves this verification URL automatically when the default location is used.', 'rankhigh-seo' ); ?></p></td></tr>
				<tr><th scope="row"><label for="rankhigh_indexnow_post_types"><?php esc_html_e( 'IndexNow post types', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_indexnow_post_types" name="rankhigh_indexnow_post_types" type="text" value="<?php echo esc_attr( $val( 'rankhigh_indexnow_post_types', 'post' ) ); ?>" class="large-text" placeholder="post, news" /></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Multilingual and international SEO', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_seo_multilingual_enabled" value="0" /><label><input name="rankhigh_seo_multilingual_enabled" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_multilingual_enabled', true ) ); ?> /> <?php esc_html_e( 'Enable hreflang and regional metadata', 'rankhigh-seo' ); ?></label></td></tr>
				<tr><th scope="row"><label for="rankhigh_seo_hreflang_map"><?php esc_html_e( 'Language / regional URL map', 'rankhigh-seo' ); ?></label></th><td><textarea id="rankhigh_seo_hreflang_map" name="rankhigh_seo_hreflang_map" rows="5" class="large-text code" placeholder="en-US=https://example.com/
fr-FR=https://fr.example.com/
ar-SA=https://example.com/ar/"><?php echo esc_textarea( $val( 'rankhigh_seo_hreflang_map' ) ); ?></textarea><p class="description"><?php esc_html_e( 'One locale=URL per line. Supports language and regional codes such as en, en-US, fr-FR, ar-SA, and de-DE. WPML and Polylang URLs are detected automatically.', 'rankhigh-seo' ); ?></p></td></tr>
				<tr><th scope="row"><label for="rankhigh_seo_x_default_url"><?php esc_html_e( 'x-default URL', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_x_default_url" name="rankhigh_seo_x_default_url" type="url" value="<?php echo esc_attr( $val( 'rankhigh_seo_x_default_url' ) ); ?>" class="large-text" /><p class="description"><?php esc_html_e( 'Optional fallback URL for visitors whose language or region is not mapped.', 'rankhigh-seo' ); ?></p></td></tr>
				</tbody></table>
				<h2><?php esc_html_e( 'Breadcrumbs', 'rankhigh-seo' ); ?></h2>
				<table class="form-table" role="presentation"><tbody>
					<tr><th scope="row"><?php esc_html_e( 'Frontend breadcrumbs', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_breadcrumbs_enabled" value="0" /><label><input name="rankhigh_breadcrumbs_enabled" type="checkbox" value="1" <?php checked( $val( 'rankhigh_breadcrumbs_enabled', true ) ); ?> /> <?php esc_html_e( 'Output breadcrumbs on singular content', 'rankhigh-seo' ); ?></label><br /><label for="rankhigh_breadcrumbs_separator"><?php esc_html_e( 'Separator', 'rankhigh-seo' ); ?></label> <input id="rankhigh_breadcrumbs_separator" name="rankhigh_breadcrumbs_separator" type="text" value="<?php echo esc_attr( $val( 'rankhigh_breadcrumbs_separator', '→' ) ); ?>" class="small-text" /></td></tr>
				</tbody></table>
				<h2><?php esc_html_e( 'Infrastructure domains', 'rankhigh-seo' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th scope="row"><label for="rankhigh_media_host"><?php esc_html_e( 'Media host', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_media_host" name="rankhigh_media_host" type="url" value="<?php echo esc_attr( $val( 'rankhigh_media_host' ) ); ?>" class="large-text" placeholder="https://images.example.com" /><p class="description"><?php esc_html_e( 'Optional. Leave empty to keep normal WordPress uploads URLs.', 'rankhigh-seo' ); ?></p></td></tr>
				<tr><th scope="row"><label for="rankhigh_cdn_host"><?php esc_html_e( 'CDN host', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_cdn_host" name="rankhigh_cdn_host" type="url" value="<?php echo esc_attr( $val( 'rankhigh_cdn_host' ) ); ?>" class="large-text" /><input type="hidden" name="rankhigh_cdn_enabled" value="0" /><label><input id="rankhigh_cdn_enabled" name="rankhigh_cdn_enabled" type="checkbox" value="1" <?php checked( $val( 'rankhigh_cdn_enabled', false ) ); ?> /> <?php esc_html_e( 'Enable CDN URL generation', 'rankhigh-seo' ); ?></label></td></tr>
				<tr><th scope="row"><label for="rankhigh_video_host"><?php esc_html_e( 'Video host', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_video_host" name="rankhigh_video_host" type="url" value="<?php echo esc_attr( $val( 'rankhigh_video_host' ) ); ?>" class="large-text" /></td></tr>
				<tr><th scope="row"><label for="rankhigh_api_host"><?php esc_html_e( 'API host', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_api_host" name="rankhigh_api_host" type="url" value="<?php echo esc_attr( $val( 'rankhigh_api_host' ) ); ?>" class="large-text" /></td></tr>
			</tbody></table>
			<h2><?php esc_html_e( 'News SEO and sitemaps', 'rankhigh-seo' ); ?></h2>
<table class="form-table" role="presentation"><tbody>
<tr><th scope="row"><?php esc_html_e( 'News sitemap', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_seo_news_enabled" value="0" /><label><input name="rankhigh_seo_news_enabled" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_news_enabled', true ) ); ?> /> <?php esc_html_e( 'Enable the News sitemap', 'rankhigh-seo' ); ?></label><p class="description"><?php esc_html_e( 'Only recently published, indexable content is included.', 'rankhigh-seo' ); ?></p></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_post_types"><?php esc_html_e( 'News post types', 'rankhigh-seo' ); ?></label></th><td><textarea id="rankhigh_seo_news_post_types" name="rankhigh_seo_news_post_types" rows="2" class="large-text" placeholder="post
news"><?php echo esc_textarea( $val( 'rankhigh_seo_news_post_types', 'post' ) ); ?></textarea><p class="description"><?php esc_html_e( 'One public post type per line or comma-separated. Invalid or non-public types are ignored.', 'rankhigh-seo' ); ?></p></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_window"><?php esc_html_e( 'News freshness window (hours)', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_news_window" name="rankhigh_seo_news_window" type="number" min="1" max="168" value="<?php echo esc_attr( $val( 'rankhigh_seo_news_window', 48 ) ); ?>" class="small-text" /><p class="description"><?php esc_html_e( 'Google News accepts fresh articles; RankHigh caps this at 168 hours.', 'rankhigh-seo' ); ?></p></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_max_urls"><?php esc_html_e( 'Maximum News URLs', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_news_max_urls" name="rankhigh_seo_news_max_urls" type="number" min="1" max="1000" value="<?php echo esc_attr( $val( 'rankhigh_seo_news_max_urls', 1000 ) ); ?>" class="small-text" /></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_exclude_ids"><?php esc_html_e( 'Exclude post IDs', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_news_exclude_ids" name="rankhigh_seo_news_exclude_ids" type="text" value="<?php echo esc_attr( $val( 'rankhigh_seo_news_exclude_ids' ) ); ?>" class="large-text" placeholder="12, 45, 89" /></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_exclude_categories"><?php esc_html_e( 'Exclude category IDs', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_seo_news_exclude_categories" name="rankhigh_seo_news_exclude_categories" type="text" value="<?php echo esc_attr( $val( 'rankhigh_seo_news_exclude_categories' ) ); ?>" class="large-text" placeholder="3, 7" /></td></tr>
<tr><th scope="row"><label for="rankhigh_seo_news_genre"><?php esc_html_e( 'News genre', 'rankhigh-seo' ); ?></label></th><td><select id="rankhigh_seo_news_genre" name="rankhigh_seo_news_genre"><option value="" <?php selected( $val( 'rankhigh_seo_news_genre' ), '' ); ?>><?php esc_html_e( 'Not specified', 'rankhigh-seo' ); ?></option><?php foreach ( array( 'Opinion', 'PressRelease', 'Satire', 'UserGenerated', 'Report', 'Review', 'Interview', 'Background', 'Transcript', 'Obituary', 'Profile' ) as $genre ) : ?><option value="<?php echo esc_attr( $genre ); ?>" <?php selected( $val( 'rankhigh_seo_news_genre' ), $genre ); ?>><?php echo esc_html( $genre ); ?></option><?php endforeach; ?></select></td></tr>
	<tr><th scope="row"><?php esc_html_e( 'News keywords', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_seo_news_keywords" value="0" /><label><input name="rankhigh_seo_news_keywords" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_news_keywords', true ) ); ?> /> <?php esc_html_e( 'Include tags, categories, and focus keyphrase as news keywords', 'rankhigh-seo' ); ?></label></td></tr>
	<tr><th scope="row"><label for="rankhigh_sitemap_post_types"><?php esc_html_e( 'Standard sitemap post types', 'rankhigh-seo' ); ?></label></th><td><input id="rankhigh_sitemap_post_types" name="rankhigh_sitemap_post_types" type="text" value="<?php echo esc_attr( $val( 'rankhigh_sitemap_post_types', 'post' ) ); ?>" class="large-text" /><p class="description"><?php esc_html_e( 'Public, queryable types included in the standard post sitemap.', 'rankhigh-seo' ); ?></p></td></tr>
	<tr><th scope="row"><?php esc_html_e( 'Additional sitemap providers', 'rankhigh-seo' ); ?></th><td><?php foreach ( array( 'Pages' => 'rankhigh_sitemap_pages_enabled', 'Custom post types' => 'rankhigh_sitemap_cpt_enabled', 'Taxonomies' => 'rankhigh_sitemap_taxonomies_enabled', 'Authors' => 'rankhigh_sitemap_authors_enabled', 'Attachments' => 'rankhigh_sitemap_attachments_enabled' ) as $label => $field ) : ?><input type="hidden" name="<?php echo esc_attr( $field ); ?>" value="0" /><label><input name="<?php echo esc_attr( $field ); ?>" type="checkbox" value="1" <?php checked( $val( $field, 'Attachments' !== $label ) ); ?> /> <?php echo esc_html( $label ); ?></label><br /><?php endforeach; ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Media sitemaps', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_seo_image_sitemap" value="0" /><label><input name="rankhigh_seo_image_sitemap" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_image_sitemap', true ) ); ?> /> <?php esc_html_e( 'Image sitemap', 'rankhigh-seo' ); ?></label><br /><input type="hidden" name="rankhigh_seo_video_sitemap" value="0" /><label><input name="rankhigh_seo_video_sitemap" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_video_sitemap', true ) ); ?> /> <?php esc_html_e( 'Video sitemap', 'rankhigh-seo' ); ?></label><br /><label for="rankhigh_image_license_url"><?php esc_html_e( 'Image license URL', 'rankhigh-seo' ); ?></label><br /><input id="rankhigh_image_license_url" name="rankhigh_image_license_url" type="url" value="<?php echo esc_attr( $val( 'rankhigh_image_license_url' ) ); ?>" class="large-text" /></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Monitoring', 'rankhigh-seo' ); ?></th><td><input type="hidden" name="rankhigh_seo_404_monitor" value="0" /><label><input name="rankhigh_seo_404_monitor" type="checkbox" value="1" <?php checked( $val( 'rankhigh_seo_404_monitor', false ) ); ?> /> <?php esc_html_e( 'Record a capped rolling 404 log', 'rankhigh-seo' ); ?></label></td></tr>
			</tbody></table>
			<?php submit_button(); ?>
		</form>
		<hr />
		<h2><?php esc_html_e( 'Settings portability', 'rankhigh-seo' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="rankhigh_seo_export" /><?php wp_nonce_field( 'rankhigh_seo_export' ); ?><?php submit_button( __( 'Export settings', 'rankhigh-seo' ), 'secondary', 'submit', false ); ?></form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="rankhigh_seo_import" /><?php wp_nonce_field( 'rankhigh_seo_import' ); ?><label for="rankhigh_seo_json"><span class="screen-reader-text"><?php esc_html_e( 'RankHigh SEO JSON settings', 'rankhigh-seo' ); ?></span></label><textarea id="rankhigh_seo_json" name="rankhigh_seo_json" rows="8" class="large-text code" required></textarea><?php submit_button( __( 'Import settings', 'rankhigh-seo' ), 'secondary' ); ?></form>
		</div>
		<?php
	}
}
