<?php
/**
 * Diagnostics screen for ownership and compatibility checks.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Admin;

use RankHighSEO\Compatibility\JNewsAdapter;
use RankHighSEO\Core\OutputRegistry;
use RankHighSEO\Sitemap\SitemapController;

final class DiagnosticsPage {
	/** @var OutputRegistry */
	private $registry;

	/** @var JNewsAdapter */
	private $jnews;

	public function __construct( OutputRegistry $registry, JNewsAdapter $jnews ) {
		$this->registry = $registry;
		$this->jnews   = $jnews;
	}

	public function register() {
		add_options_page( __( 'RankHigh SEO Diagnostics', 'rankhigh-seo' ), __( 'SEO Diagnostics', 'rankhigh-seo' ), 'manage_options', 'rankhigh-seo-diagnostics', array( $this, 'render' ) );
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$compatibility = $this->jnews->diagnostics();
		echo '<div class="wrap"><h1>' . esc_html__( 'RankHigh SEO Diagnostics', 'rankhigh-seo' ) . '</h1>';
		$this->row( __( 'JNews compatibility', 'rankhigh-seo' ), $compatibility['status'], $compatibility['message'] );
		$this->row( __( 'Title', 'rankhigh-seo' ), $this->registry->has( 'title' ) ? 'PASS' : 'WARNING', __( 'Document title ownership is registered by RankHigh.', 'rankhigh-seo' ) );
		$this->row( __( 'Meta description', 'rankhigh-seo' ), $this->registry->has( 'description' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns the description slot when the head renders.', 'rankhigh-seo' ) );
		$this->row( __( 'Canonical', 'rankhigh-seo' ), $this->registry->has( 'canonical' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns the canonical slot when the head renders.', 'rankhigh-seo' ) );
		$this->row( __( 'Robots', 'rankhigh-seo' ), $this->registry->has( 'robots' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns the robots slot when the head renders.', 'rankhigh-seo' ) );
		$this->row( __( 'Open Graph', 'rankhigh-seo' ), $this->registry->has( 'og' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns the Open Graph slot when the head renders.', 'rankhigh-seo' ) );
		$this->row( __( 'Twitter', 'rankhigh-seo' ), $this->registry->has( 'twitter' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns the Twitter slot when the head renders.', 'rankhigh-seo' ) );
			$this->row( __( 'JSON-LD graph', 'rankhigh-seo' ), $this->registry->has( 'jsonld' ) ? 'PASS' : 'WARNING', __( 'RankHigh owns one JSON-LD graph slot per request.', 'rankhigh-seo' ) );
			$engine = ( new SitemapController() )->engine(); $providers = $engine->providers(); $enabled = 0; $shards = 0;
			foreach ( $providers as $provider ) { if ( $provider->is_enabled() ) { $enabled++; $shards += $provider->get_shard_count(); } }
			$this->row( __( 'Sitemap index', 'rankhigh-seo' ), $enabled ? 'PASS' : 'WARNING', sprintf( __( '%d active providers and %d generated shard(s).', 'rankhigh-seo' ), $enabled, $shards ) );
			$this->row( __( 'Sitemap cache', 'rankhigh-seo' ), get_option( 'rankhigh_seo_cache_epoch', false ) ? 'PASS' : 'WARNING', sprintf( __( 'Cache epoch %s; last invalidation %s.', 'rankhigh-seo' ), (string) get_option( 'rankhigh_seo_cache_epoch', 'not initialized' ), get_option( 'rankhigh_seo_last_invalidation', 'not recorded' ) ) );
		echo '</div>';
	}

	private function row( $label, $status, $message ) {
		$class = 'PASS' === strtoupper( $status ) ? 'notice-success' : ( 'ERROR' === strtoupper( $status ) ? 'notice-error' : 'notice-warning' );
		echo '<div class="notice ' . esc_attr( $class ) . '"><p><strong>' . esc_html( $status ) . '</strong> — ' . esc_html( $label ) . ': ' . esc_html( $message ) . '</p></div>';
	}
}
