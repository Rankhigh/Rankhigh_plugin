<?php
/**
 * Safe settings import and export.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Admin;

final class ImportExport {
	/** @var string[] */
		private $allowed = array(
			'rankhigh_indexnow_enabled',
			'rankhigh_indexnow_key_location',
			'rankhigh_indexnow_post_types',
			'rankhigh_seo_publication_name',
			'rankhigh_seo_publisher_name',
			'rankhigh_seo_publisher_type',
			'rankhigh_seo_publisher_logo',
			'rankhigh_publication_short_name',
			'rankhigh_primary_url',
			'rankhigh_media_host',
			'rankhigh_cdn_enabled',
			'rankhigh_cdn_host',
			'rankhigh_video_host',
			'rankhigh_api_host',
			'rankhigh_default_language',
			'rankhigh_default_locale',
			'rankhigh_timezone',
			'rankhigh_country',
			'rankhigh_copyright',
			'rankhigh_contact',
			'rankhigh_social_profiles',
			'rankhigh_seo_title_separator',
			'rankhigh_seo_default_robots',
			'rankhigh_seo_title_template_home',
			'rankhigh_seo_title_template_post',
			'rankhigh_seo_title_template_page',
			'rankhigh_seo_title_template_archive',
			'rankhigh_sitemap_post_types',
			'rankhigh_sitemap_pages_enabled',
			'rankhigh_sitemap_cpt_enabled',
			'rankhigh_sitemap_taxonomies_enabled',
			'rankhigh_sitemap_authors_enabled',
			'rankhigh_sitemap_attachments_enabled',
			'rankhigh_seo_image_sitemap',
			'rankhigh_seo_video_sitemap',
			'rankhigh_image_license_url',
			'rankhigh_breadcrumbs_enabled',
			'rankhigh_breadcrumbs_separator',
			'rankhigh_seo_multilingual_enabled',
			'rankhigh_seo_hreflang_map',
			'rankhigh_seo_x_default_url',
			'rankhigh_seo_news_enabled',
			'rankhigh_seo_news_window',
			'rankhigh_seo_news_post_types',
			'rankhigh_seo_news_max_urls',
			'rankhigh_seo_news_exclude_ids',
			'rankhigh_seo_news_exclude_categories',
			'rankhigh_seo_news_keywords',
			'rankhigh_seo_news_genre',
		'rankhigh_seo_redirects',
		'rankhigh_seo_404_monitor',
		'rankhigh_seo_404_log',
	);

	/** Register admin actions. */
	public function register() {
		add_action( 'admin_post_rankhigh_seo_export', array( $this, 'export' ) );
		add_action( 'admin_post_rankhigh_seo_import', array( $this, 'import' ) );
	}

	/** Export only RankHigh-owned options. */
	public function export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to export RankHigh SEO settings.', 'rankhigh-seo' ), 403 );
		}
		check_admin_referer( 'rankhigh_seo_export' );
		$data = array();
		foreach ( $this->allowed as $key ) {
			$value = get_option( $key, null );
			if ( null !== $value ) {
				$data[ $key ] = $value;
			}
		}
			$data['_schema'] = 'rankhigh-seo/v2';
		header( 'Content-Type: application/json; charset=' . get_bloginfo( 'charset' ) );
		header( 'Content-Disposition: attachment; filename=rankhigh-seo-settings.json' );
		echo wp_json_encode( $data, JSON_PRETTY_PRINT );
		exit;
	}

	/** Import a schema-validated JSON payload. */
	public function import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to import RankHigh SEO settings.', 'rankhigh-seo' ), 403 );
		}
		check_admin_referer( 'rankhigh_seo_import' );
		$raw = isset( $_POST['rankhigh_seo_json'] ) ? wp_unslash( $_POST['rankhigh_seo_json'] ) : '';
		$data = json_decode( $raw, true );
			if ( ! is_array( $data ) || ! in_array( ( $data['_schema'] ?? '' ), array( 'rankhigh-seo/v1', 'rankhigh-seo/v2' ), true ) ) {
			wp_die( esc_html__( 'The import file is invalid.', 'rankhigh-seo' ), 400 );
		}
		foreach ( $data as $key => $value ) {
			if ( '_schema' === $key || ! in_array( $key, $this->allowed, true ) ) {
				continue;
			}
			update_option( $key, $this->sanitize( $key, $value ), false );
		}
		update_option( 'rankhigh_seo_cache_epoch', time(), false );
		wp_safe_redirect( add_query_arg( 'rankhigh_seo_imported', '1', admin_url( 'options-general.php?page=rankhigh-seo' ) ) );
		exit;
	}

	/** @param string $key @param mixed $value @return mixed */
	private function sanitize( $key, $value ) {
		if ( 'rankhigh_indexnow_enabled' === $key ) {
				return (bool) $value;
			}
			if ( 'rankhigh_indexnow_key_location' === $key ) {
				return esc_url_raw( (string) $value );
			}
			if ( 'rankhigh_seo_x_default_url' === $key ) {
				return esc_url_raw( (string) $value );
			}
			if ( 'rankhigh_seo_multilingual_enabled' === $key || 'rankhigh_seo_news_enabled' === $key || 'rankhigh_seo_news_keywords' === $key ) {
				return (bool) $value;
			}
			if ( 'rankhigh_seo_news_max_urls' === $key ) {
				return max( 1, min( 1000, absint( $value ) ) );
			}
			if ( 'rankhigh_seo_news_window' === $key ) {
			return max( 1, min( 168, absint( $value ) ) );
		}
		if ( 'rankhigh_seo_404_monitor' === $key ) {
			return (bool) $value;
		}
		if ( 'rankhigh_seo_redirects' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}
			$redirects = array();
			foreach ( $value as $redirect ) {
				if ( ! is_array( $redirect ) ) {
					continue;
				}
				$source = sanitize_text_field( (string) ( $redirect['source'] ?? '' ) );
				$target = esc_url_raw( (string) ( $redirect['target'] ?? '' ) );
				$status = absint( $redirect['status'] ?? 301 );
				if ( '' === $source || ( '' === $target && 410 !== $status ) || ! in_array( $status, array( 301, 302, 307, 410 ), true ) ) {
					continue;
				}
				$redirects[] = array(
					'source' => '/' . ltrim( wp_parse_url( $source, PHP_URL_PATH ) ?: '', '/' ),
					'target' => $target,
					'status' => $status,
				);
			}
			return array_slice( $redirects, 0, 500 );
		}
		if ( 'rankhigh_seo_404_log' === $key ) {
			return is_array( $value ) ? array_slice( array_map( static function ( $entry ) {
				return is_array( $entry ) ? array(
					'path' => sanitize_text_field( (string) ( $entry['path'] ?? '/' ) ),
					'time' => sanitize_text_field( (string) ( $entry['time'] ?? '' ) ),
				) : array();
			}, $value ), -500 ) : array();
		}
		return sanitize_text_field( (string) $value );
	}
}
/* EOF */
