<?php
/** Post-level SEO fields and sanitization. */
namespace RankHighSEO\Meta;

final class PostMeta {
	const TITLE = '_rankhigh_seo_title';
	const DESCRIPTION = '_rankhigh_seo_description';
	const ROBOTS = '_rankhigh_seo_robots';
	const CANONICAL = '_rankhigh_seo_canonical';
	const OG_TITLE = '_rankhigh_seo_og_title';
	const OG_DESCRIPTION = '_rankhigh_seo_og_description';
	const OG_IMAGE = '_rankhigh_seo_og_image';
	const TWITTER_CARD = '_rankhigh_seo_twitter_card';
	const FOCUS_KEYWORD = '_rankhigh_seo_focus_keyword';
	const CORNERSTONE = '_rankhigh_seo_cornerstone';
	const PRIMARY_CATEGORY = '_rankhigh_seo_primary_category';
	const VIDEO_THUMBNAIL = '_rankhigh_seo_video_thumbnail';
	const VIDEO_DURATION = '_rankhigh_seo_video_duration';
	const SCHEMA_TYPE = '_rankhigh_seo_schema_type';
	const NEWS_ELIGIBLE = '_rankhigh_seo_news_eligible';
	const AUTHOR_NAME = '_rankhigh_seo_author_name';
	const AUTHOR_JOB_TITLE = '_rankhigh_seo_author_job_title';
	const AUTHOR_IMAGE = '_rankhigh_seo_author_image';

	public static function get( $post_id, $key, $default = '' ) {
		$value = get_post_meta( $post_id, $key, true );
		return '' === $value ? $default : $value;
	}

	public static function sanitize_text( $value, $length = 255 ) {
		$value = sanitize_text_field( wp_unslash( (string) $value ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length ) : substr( $value, 0, $length );
	}

	public static function sanitize_url( $value ) {
		$value = esc_url_raw( wp_unslash( (string) $value ) );
		return wp_validate_redirect( $value, '' ) ? $value : '';
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['rankhigh_seo_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rankhigh_seo_meta_nonce'] ) ), 'rankhigh_seo_meta' ) ) { return; }
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
		$text_fields = array(
			self::TITLE => 255, self::DESCRIPTION => 320, self::OG_TITLE => 255,
			self::OG_DESCRIPTION => 320, self::FOCUS_KEYWORD => 100, self::VIDEO_DURATION => 32,
			self::AUTHOR_NAME => 255, self::AUTHOR_JOB_TITLE => 120,
		);
		foreach ( $text_fields as $key => $length ) {
			if ( isset( $_POST[ $key ] ) ) { update_post_meta( $post_id, $key, self::sanitize_text( $_POST[ $key ], $length ) ); }
		}
		foreach ( array( self::CANONICAL, self::OG_IMAGE, self::VIDEO_THUMBNAIL, self::AUTHOR_IMAGE ) as $key ) {
			if ( isset( $_POST[ $key ] ) ) { update_post_meta( $post_id, $key, self::sanitize_url( $_POST[ $key ] ) ); }
		}
		if ( isset( $_POST[ self::ROBOTS ] ) ) {
			$robots = sanitize_text_field( wp_unslash( $_POST[ self::ROBOTS ] ) );
			$allowed = array( 'index,follow', 'noindex,follow', 'noindex,nofollow', 'index,nofollow' );
			update_post_meta( $post_id, self::ROBOTS, in_array( $robots, $allowed, true ) ? $robots : 'index,follow' );
		}
		if ( isset( $_POST[ self::TWITTER_CARD ] ) ) {
			$card = sanitize_text_field( wp_unslash( $_POST[ self::TWITTER_CARD ] ) );
			update_post_meta( $post_id, self::TWITTER_CARD, in_array( $card, array( 'summary', 'summary_large_image' ), true ) ? $card : 'summary_large_image' );
		}
		if ( isset( $_POST[ self::SCHEMA_TYPE ] ) ) {
			$type = sanitize_key( wp_unslash( $_POST[ self::SCHEMA_TYPE ] ) );
			update_post_meta( $post_id, self::SCHEMA_TYPE, in_array( $type, array( 'NewsArticle', 'Article', 'BlogPosting' ), true ) ? $type : 'NewsArticle' );
		}
		update_post_meta( $post_id, self::NEWS_ELIGIBLE, isset( $_POST[ self::NEWS_ELIGIBLE ] ) ? '1' : '0' );
		update_post_meta( $post_id, self::CORNERSTONE, isset( $_POST[ self::CORNERSTONE ] ) ? '1' : '0' );
		if ( isset( $_POST[ self::PRIMARY_CATEGORY ] ) ) {
			$category_id = absint( wp_unslash( $_POST[ self::PRIMARY_CATEGORY ] ) );
			update_post_meta( $post_id, self::PRIMARY_CATEGORY, term_exists( $category_id, 'category' ) ? (string) $category_id : '' );
		}
	}
}
