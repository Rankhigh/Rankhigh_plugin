<?php
/** Technical head metadata output. */
namespace RankHighSEO\Meta;

use RankHighSEO\Core\OutputRegistry;
use RankHighSEO\Core\PublicationProfile;

final class HeadOutput {
	/** @var OutputRegistry */
	private $registry;
	/** @var MetaGenerator */
	private $meta;

	public function __construct( OutputRegistry $registry, MetaGenerator $meta = null ) {
		$this->registry = $registry;
		$this->meta     = $meta ? $meta : new MetaGenerator();
	}

	public function register() {
		add_filter( 'pre_get_document_title', array( $this, 'title' ), 99 );
		add_action( 'wp_head', array( $this, 'render' ), 1 );
	}

	public function title( $title ) {
		if ( is_admin() || wp_doing_ajax() ) {
			return $title;
		}

		$generated = $this->meta->title();
		if ( '' !== $generated ) {
			$this->registry->claim( 'title', 'head-output' );
		}
		return '' !== $generated ? $generated : $title;
	}

	public function render() {
		if ( is_admin() || wp_doing_ajax() ) {
			return;
		}
			// Privacy-safe attribution: these markers identify the active SEO layer without tracking visitors.
			echo "<!-- RankHigh SEO: begin; version=1.5.0; output=technical,social,news -->\n";
			echo '<meta name="generator" content="RankHigh SEO 1.5.0" />' . "\n";
			echo '<meta name="rankhigh-seo" content="active" />' . "\n";
			echo "<!-- RankHigh SEO: technical metadata begin -->\n";
		$description = $this->meta->description();
		if ( $this->registry->claim( 'description' ) && '' !== $description ) {
			echo '<meta name="description" content="' . esc_attr( $description ) . '" />' . "\n";
		}
		if ( $this->registry->claim( 'canonical' ) ) {
			echo '<link rel="canonical" href="' . esc_url( $this->meta->canonical() ) . '" />' . "\n";
		}
			if ( $this->registry->claim( 'robots' ) ) {
				echo '<meta name="robots" content="' . esc_attr( $this->meta->robots() ) . '" />' . "\n";
			}
			echo "<!-- RankHigh SEO: technical metadata end -->\n";
			if ( is_singular( 'post' ) && $this->registry->claim( 'news-meta' ) ) {
				echo "<!-- RankHigh SEO: News SEO metadata begin; type=NewsArticle -->\n";
			$post_id = get_queried_object_id();
			echo '<meta property="article:published_time" content="' . esc_attr( get_post_time( DATE_W3C, true, $post_id ) ) . '" />' . "\n";
			echo '<meta property="article:modified_time" content="' . esc_attr( get_post_modified_time( DATE_W3C, true, $post_id ) ) . '" />' . "\n";
			echo '<meta property="article:section" content="' . esc_attr( $this->meta->section() ) . '" />' . "\n";
				foreach ( $this->meta->keywords() as $keyword ) {
					echo '<meta property="article:tag" content="' . esc_attr( $keyword ) . '" />' . "\n";
				}
				echo "<!-- RankHigh SEO: News SEO metadata end -->\n";
			}
			$image = $this->image();
			if ( $this->registry->claim( 'og' ) ) {
				echo "<!-- RankHigh SEO: Open Graph metadata begin -->\n";
			echo '<meta property="og:title" content="' . esc_attr( $this->meta->title() ) . '" />' . "\n";
			echo '<meta property="og:site_name" content="' . esc_attr( PublicationProfile::publication_name() ) . '" />' . "\n";
			echo '<meta property="og:description" content="' . esc_attr( $description ) . '" />' . "\n";
			echo '<meta property="og:url" content="' . esc_url( $this->meta->canonical() ) . '" />' . "\n";
			echo '<meta property="og:type" content="' . esc_attr( is_singular( 'post' ) ? 'article' : 'website' ) . '" />' . "\n";
				$locale = str_replace( '-', '_', sanitize_text_field( (string) get_option( 'rankhigh_default_locale', get_locale() ) ) );
				echo '<meta property="og:locale" content="' . esc_attr( $locale ) . '" />' . "\n";
				foreach ( LanguageAlternates::alternates() as $alternate_locale => $alternate_url ) {
					$alternate_locale = str_replace( '-', '_', $alternate_locale );
					if ( $alternate_locale !== $locale ) {
						echo '<meta property="og:locale:alternate" content="' . esc_attr( $alternate_locale ) . '" />' . "\n";
					}
				}
				if ( $image ) {
					echo '<meta property="og:image" content="' . esc_url( $image ) . '" />' . "\n";
				}
				echo "<!-- RankHigh SEO: Open Graph metadata end -->\n";
			}
			if ( $this->registry->claim( 'twitter' ) ) {
				echo "<!-- RankHigh SEO: X/Twitter metadata begin -->\n";
			echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
			echo '<meta name="twitter:title" content="' . esc_attr( $this->meta->title() ) . '" />' . "\n";
			echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '" />' . "\n";
				if ( $image ) {
					echo '<meta name="twitter:image" content="' . esc_url( $image ) . '" />' . "\n";
				}
				echo "<!-- RankHigh SEO: X/Twitter metadata end -->\n";
			}
			echo "<!-- RankHigh SEO: end -->\n";
	}

	/** @return string */
	private function image() {
		if ( ! is_singular( 'post' ) ) {
			return '';
		}
		$image = get_the_post_thumbnail_url( get_queried_object_id(), 'full' );
		return $image ? PublicationProfile::asset_url( (string) $image ) : '';
	}
}

/* EOF */
