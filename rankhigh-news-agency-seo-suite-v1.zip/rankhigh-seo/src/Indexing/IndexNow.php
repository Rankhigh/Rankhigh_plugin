<?php
/** Instant URL discovery for supported search engines via IndexNow. */
namespace RankHighSEO\Indexing;

final class IndexNow {
	public function register() {
		add_action( 'init', array( $this, 'rewrite' ) );
		add_action( 'template_redirect', array( $this, 'key_endpoint' ) );
		add_action( 'save_post', array( $this, 'queue' ), 30, 3 );
		add_action( 'rankhigh_indexnow_submit', array( $this, 'submit' ) );
	}

	public function rewrite() {
		add_rewrite_tag( '%rankhigh_indexnow_key%', '([0-1])' );
		add_rewrite_rule( '^rankhigh-indexnow-key\.txt$', 'index.php?rankhigh_indexnow_key=1', 'top' );
	}

	public function key_endpoint() {
		if ( '1' !== (string) get_query_var( 'rankhigh_indexnow_key' ) ) {
			return;
		}
		$key = sanitize_text_field( (string) get_option( 'rankhigh_indexnow_key', '' ) );
		if ( ! $key ) {
			status_header( 404 );
			exit;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=' . get_bloginfo( 'charset' ) );
		echo $key;
		exit;
	}

	/** @param int $post_id @param \WP_Post $post @param bool $update */
	public function queue( $post_id, $post, $update ) {
		if ( ! get_option( 'rankhigh_indexnow_enabled', false ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'publish' !== $post->post_status || ! $this->allowed_type( $post->post_type ) ) {
			return;
		}
		if ( ! wp_next_scheduled( 'rankhigh_indexnow_submit', array( $post_id ) ) ) {
			wp_schedule_single_event( time() + 15, 'rankhigh_indexnow_submit', array( $post_id ) );
		}
	}

	/** @param int $post_id */
	public function submit( $post_id ) {
		$key = sanitize_text_field( (string) get_option( 'rankhigh_indexnow_key', '' ) );
		if ( ! get_option( 'rankhigh_indexnow_enabled', false ) || ! $key || ! $this->allowed_type( get_post_type( $post_id ) ) ) {
			return;
		}
		$url = esc_url_raw( get_permalink( $post_id ) );
		$host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		if ( ! $url || ! $host ) {
			return;
		}
		$key_location = esc_url_raw( (string) get_option( 'rankhigh_indexnow_key_location', home_url( '/rankhigh-indexnow-key.txt' ) ) );
		$response = wp_remote_post(
			'https://api.indexnow.org/indexnow',
			array(
				'timeout' => 8,
				'blocking' => true,
				'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body' => wp_json_encode( array( 'host' => $host, 'key' => $key, 'keyLocation' => $key_location, 'urlList' => array( $url ) ) ),
			)
		);
		$status = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		update_option( 'rankhigh_indexnow_last_status', $status . ':' . gmdate( 'c' ), false );
	}

	/** @param string $type @return bool */
	private function allowed_type( $type ) {
		$types = preg_split( '/[\s,]+/', (string) get_option( 'rankhigh_indexnow_post_types', 'post' ), -1, PREG_SPLIT_NO_EMPTY );
		return in_array( $type, array_map( 'sanitize_key', $types ), true );
	}
}
