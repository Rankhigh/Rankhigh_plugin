<?php
namespace RankHighSEO\SEO;

use RankHighSEO\Core\PublicationProfile;
use RankHighSEO\Meta\MetaGenerator;

final class BreadcrumbEngine {
	public function register() {
		add_shortcode( 'rankhigh_breadcrumbs', array( $this, 'shortcode' ) );
		add_filter( 'the_content', array( $this, 'prepend' ), 20 );
	}
	public function prepend( $content ) {
		$original = $content;
		if ( is_admin() || is_feed() || ! is_singular() || ! get_option( 'rankhigh_breadcrumbs_enabled', true ) || ! in_the_loop() || ! is_main_query() ) { return $original; }
		return $this->render() . $content;
	}
	public function shortcode() { return $this->render(); }
	public function items() {
		$items = array( array( 'name' => PublicationProfile::publication_name(), 'url' => PublicationProfile::primary_url() ) );
		if ( is_page() ) {
			$ancestors = array_reverse( get_post_ancestors( get_queried_object_id() ) );
			foreach ( $ancestors as $ancestor ) { $items[] = array( 'name' => get_the_title( $ancestor ), 'url' => get_permalink( $ancestor ) ); }
		} elseif ( is_singular() ) {
			$post_type = get_post_type(); $object = get_post_type_object( $post_type );
			if ( $object && 'post' !== $post_type ) { $items[] = array( 'name' => $object->labels->singular_name, 'url' => get_post_type_archive_link( $post_type ) ); }
			$taxonomy = $this->primary_taxonomy( $post_type );
			if ( $taxonomy ) {
				$terms = get_the_terms( get_queried_object_id(), $taxonomy->name );
				if ( is_array( $terms ) && ! empty( $terms ) ) { $items = $this->append_term_trail( $items, $terms[0], $taxonomy->name ); }
			}
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object(); if ( $term instanceof \WP_Term ) { $items = $this->append_term_trail( $items, $term, $term->taxonomy ); }
		} elseif ( is_post_type_archive() ) {
			$object = get_queried_object(); if ( $object && ! empty( $object->labels->name ) ) { $items[] = array( 'name' => $object->labels->name, 'url' => get_post_type_archive_link( $object->name ) ); }
		}
		$current = wp_get_document_title(); $canonical = ( new MetaGenerator() )->canonical();
		if ( $current && ( empty( $items ) || end( $items )['name'] !== $current ) ) { $items[] = array( 'name' => $current, 'url' => $canonical ); }
		return array_values( array_filter( $items, function ( $item ) { return ! empty( $item['name'] ) && ! empty( $item['url'] ); } ) );
	}
	private function primary_taxonomy( $post_type ) {
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );
		foreach ( $taxonomies as $taxonomy ) { if ( $taxonomy->public && $taxonomy->hierarchical ) { return $taxonomy; } }
		return null;
	}
	private function append_term_trail( $items, $term, $taxonomy ) {
		$ancestors = array_reverse( get_ancestors( $term->term_id, $taxonomy ) );
		foreach ( array_merge( $ancestors, array( $term->term_id ) ) as $term_id ) { $ancestor = get_term( $term_id, $taxonomy ); if ( $ancestor && ! is_wp_error( $ancestor ) ) { $items[] = array( 'name' => $ancestor->name, 'url' => get_term_link( $ancestor ) ); } }
		return $items;
	}
	public function render() {
		$items = $this->items(); $separator = sanitize_text_field( (string) get_option( 'rankhigh_breadcrumbs_separator', '→' ) ); $html = '<nav class="rankhigh-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumbs', 'rankhigh-seo' ) . '"><ol>';
		$last = count( $items ) - 1;
		foreach ( $items as $index => $item ) { $html .= '<li>' . ( $index < $last ? '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a>' : '<span aria-current="page">' . esc_html( $item['name'] ) . '</span>' ) . ( $index < $last ? '<span class="rankhigh-breadcrumb-separator" aria-hidden="true"> ' . esc_html( $separator ) . ' </span>' : '' ) . '</li>'; }
		return $html . '</ol></nav>';
	}
	public function schema() {
		$list = array(); foreach ( $this->items() as $position => $item ) { $list[] = array( '@type' => 'ListItem', 'position' => $position + 1, 'name' => wp_strip_all_tags( $item['name'] ), 'item' => esc_url_raw( $item['url'] ) ); }
		return array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );
	}
}
