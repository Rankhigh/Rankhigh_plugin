<?php
/** Premium-style technical SEO features implemented without third-party dependencies. */
namespace RankHighSEO\SEO;

use RankHighSEO\Meta\PostMeta;

final class AdvancedFeatures {
	/** Register supported frontend and editor hooks. */
	public function register() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post', array( PostMeta::class, 'save' ), 10 );
		add_action( 'wp_head', array( $this, 'render_pagination_links' ), 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( $this, 'exclude_noindex_posts' ), 10, 2 );
	}

	/** Add editorial controls to posts without changing theme presentation. */
	public function add_meta_box() {
		add_meta_box( 'rankhigh-seo-meta', __( 'RankHigh SEO', 'rankhigh-seo' ), array( $this, 'render_meta_box' ), 'post', 'normal', 'high' );
	}

	/** @param \WP_Post $post Render fields. */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'rankhigh_seo_meta', 'rankhigh_seo_meta_nonce' );
		$analysis = ( new KeywordDensityChecker() )->analyze( $post );
		$fields = array(
			PostMeta::TITLE => __( 'SEO title', 'rankhigh-seo' ),
			PostMeta::DESCRIPTION => __( 'Meta description', 'rankhigh-seo' ),
			PostMeta::CANONICAL => __( 'Canonical URL', 'rankhigh-seo' ),
			PostMeta::OG_TITLE => __( 'Social title', 'rankhigh-seo' ),
			PostMeta::OG_DESCRIPTION => __( 'Social description', 'rankhigh-seo' ),
			PostMeta::OG_IMAGE => __( 'Social image URL', 'rankhigh-seo' ),
			PostMeta::FOCUS_KEYWORD => __( 'Focus keyphrase', 'rankhigh-seo' ),
			PostMeta::VIDEO_THUMBNAIL => __( 'Video thumbnail URL', 'rankhigh-seo' ),
			PostMeta::VIDEO_DURATION => __( 'Video duration (ISO 8601)', 'rankhigh-seo' ),
		);
		$primary_category = absint( PostMeta::get( $post->ID, PostMeta::PRIMARY_CATEGORY, 0 ) );
		echo '<p>' . esc_html__( 'These fields control technical search output only; the JNews theme remains responsible for presentation.', 'rankhigh-seo' ) . '</p>';
		if ( $analysis['keyword'] ) {
			echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Keyword density', 'rankhigh-seo' ) . '</strong>: ' . esc_html( $analysis['keyword'] ) . ' — ' . esc_html( (string) $analysis['count'] ) . ' occurrence(s), ' . esc_html( (string) $analysis['density'] ) . '%, ' . esc_html( $analysis['status'] ) . '.</p><p class="description">' . esc_html__( 'Healthy guidance is 0.5%–3%; this is an editorial signal, not a ranking guarantee.', 'rankhigh-seo' ) . '</p></div>';
		} else {
			echo '<p class="description">' . esc_html__( 'Enter a focus keyphrase to calculate its density automatically from the title and content.', 'rankhigh-seo' ) . '</p>';
		}
		foreach ( $fields as $key => $label ) {
			$type = false !== strpos( $key, 'description' ) ? 'textarea' : 'text';
			$value = PostMeta::get( $post->ID, $key );
			echo '<p><label for="' . esc_attr( $key ) . '"><strong>' . esc_html( $label ) . '</strong></label><br />';
			if ( 'textarea' === $type ) {
				echo '<textarea class="widefat" rows="3" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
			} else {
				echo '<input class="widefat" type="text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
			}
			echo '</p>';
		}
		echo '<p><label for="' . esc_attr( PostMeta::PRIMARY_CATEGORY ) . '"><strong>' . esc_html__( 'Primary category', 'rankhigh-seo' ) . '</strong></label><br />';
		echo '<select class="widefat" id="' . esc_attr( PostMeta::PRIMARY_CATEGORY ) . '" name="' . esc_attr( PostMeta::PRIMARY_CATEGORY ) . '"><option value="0">' . esc_html__( 'Use the post category', 'rankhigh-seo' ) . '</option>';
		foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) {
			echo '<option value="' . esc_attr( $category->term_id ) . '" ' . selected( $primary_category, $category->term_id, false ) . '>' . esc_html( $category->name ) . '</option>';
		}
		echo '</select></p>';
		echo '<p><label><input type="checkbox" name="' . esc_attr( PostMeta::CORNERSTONE ) . '" value="1" ' . checked( PostMeta::get( $post->ID, PostMeta::CORNERSTONE, '0' ), '1', false ) . ' /> ' . esc_html__( 'Mark as cornerstone content', 'rankhigh-seo' ) . '</label></p>';
		echo '<p><label for="' . esc_attr( PostMeta::ROBOTS ) . '"><strong>' . esc_html__( 'Robots directive', 'rankhigh-seo' ) . '</strong></label><br />';
		echo '<select class="widefat" id="' . esc_attr( PostMeta::ROBOTS ) . '" name="' . esc_attr( PostMeta::ROBOTS ) . '">';
		foreach ( array( 'index,follow', 'noindex,follow', 'noindex,nofollow' ) as $robots ) {
			echo '<option value="' . esc_attr( $robots ) . '" ' . selected( PostMeta::get( $post->ID, PostMeta::ROBOTS, 'index,follow' ), $robots, false ) . '>' . esc_html( $robots ) . '</option>';
		}
		echo '</select></p>';
	}

	/** Emit rel prev/next on paginated archives. */
	public function render_pagination_links() {
		if ( is_singular() || is_admin() ) {
			return;
		}
		$prev = get_previous_posts_page_link();
		$next = get_next_posts_page_link();
		if ( $prev ) {
			echo '<link rel="prev" href="' . esc_url( $prev ) . '" />' . "\n";
		}
		if ( $next ) {
			echo '<link rel="next" href="' . esc_url( $next ) . '" />' . "\n";
		}
	}

	/** Keep noindex posts out of the core posts sitemap. */
	public function exclude_noindex_posts( $args, $post_type ) {
		if ( 'post' !== $post_type ) {
			return $args;
		}
		$args['meta_query'] = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array();
		$args['meta_query'][] = array(
			'relation' => 'OR',
			array( 'key' => PostMeta::ROBOTS, 'compare' => 'NOT EXISTS' ),
			array( 'key' => PostMeta::ROBOTS, 'value' => 'noindex', 'compare' => 'NOT LIKE' ),
		);
		return $args;
	}

}

/* EOF */
