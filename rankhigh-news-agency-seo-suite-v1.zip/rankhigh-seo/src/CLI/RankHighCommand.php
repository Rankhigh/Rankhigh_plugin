<?php
namespace RankHighSEO\CLI;

use RankHighSEO\Sitemap\SitemapController;

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	class RankHighCommand {
		private function engine() { return ( new SitemapController() )->engine(); }
		/** Regenerate sitemap caches. */
		public function sitemap( $args, $assoc_args ) {
			$engine = $this->engine(); $type = isset( $assoc_args['type'] ) ? sanitize_key( $assoc_args['type'] ) : '';
			if ( 'clear-cache' === ( $args[0] ?? '' ) ) { $engine->clear_cache(); \WP_CLI::success( 'RankHigh sitemap cache epoch advanced.' ); return; }
			if ( 'status' === ( $args[0] ?? '' ) ) { foreach ( $engine->providers() as $provider ) { \WP_CLI::line( $provider->get_slug() . ': ' . ( $provider->is_enabled() ? 'enabled' : 'disabled' ) . ', shards=' . $provider->get_shard_count() ); } return; }
			foreach ( $engine->providers() as $provider ) { if ( $type && $type !== $provider->get_slug() ) { continue; } for ( $shard = 1; $shard <= $provider->get_shard_count(); $shard++ ) { $engine->render( $provider->get_slug(), $shard ); } }
			\WP_CLI::success( $type ? 'Regenerated ' . $type . ' sitemap.' : 'Regenerated enabled sitemaps.' );
		}
	}
	\WP_CLI::add_command( 'rankhigh sitemap', __NAMESPACE__ . '\\RankHighCommand' );
}
