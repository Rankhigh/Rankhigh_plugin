<?php
/**
 * Emits one schema graph for the current document.
 *
 * @package RankHighSEO
 */
namespace RankHighSEO\Schema;

use RankHighSEO\Core\OutputRegistry;
use RankHighSEO\Core\PublicationProfile;
use RankHighSEO\SEO\BreadcrumbEngine;
use RankHighSEO\Schema\SchemaAutomation;

final class GraphOutput {
	/** @var OutputRegistry */
	private $registry;

	/** @param OutputRegistry $registry Output registry. */
	public function __construct( OutputRegistry $registry ) {
		$this->registry = $registry;
	}

	/** Register the frontend hook. */
	public function register() {
		add_action( 'wp_head', array( $this, 'render' ), 20 );
	}

	/** Render one JSON-LD graph when RankHigh owns the slot. */
	public function render() {
		if ( is_admin() || wp_doing_ajax() || ! $this->registry->claim( 'jsonld', 'graph-output' ) ) {
			return;
		}

			$graph = array( $this->organization(), $this->website(), $this->webpage() );
		if ( is_singular( 'post' ) ) {
			$graph[] = $this->article();
		}
		$automated = ( new SchemaAutomation() )->for_current_document();
		if ( is_array( $automated ) ) {
			if ( ! is_singular( 'post' ) && ! empty( $automated['primary'] ) ) { $graph[] = $automated['primary']; }
			if ( ! empty( $automated['faq'] ) ) { $graph[] = $automated['faq']; }
		}
		if ( is_singular() && function_exists( 'yoast_breadcrumb' ) === false ) {
			$graph[] = ( new BreadcrumbEngine() )->schema();
		}

			echo "<!-- RankHigh SEO: schema graph begin; entities=organization,webpage" . ( is_singular( 'post' ) ? ',article' : '' ) . " -->\n";
			echo '<script type="application/ld+json">' . wp_json_encode(
				array( '@context' => 'https://schema.org', '@graph' => $graph ),
				JSON_UNESCAPED_SLASHES
			) . '</script>' . "\n";
			echo "<!-- RankHigh SEO: schema graph end -->\n";
	}

/** @return array<string, mixed> */
	private function organization() {
$logo_url = esc_url_raw( (string) get_option( 'rankhigh_seo_publisher_logo', '' ) );
$logo = get_theme_mod( 'custom_logo' );
$logo_url = $logo_url ? $logo_url : ( $logo ? wp_get_attachment_image_url( (int) $logo, 'full' ) : '' );
if ( ! $logo_url && function_exists( 'get_site_icon_url' ) ) {
$logo_url = get_site_icon_url( 512 );
}
$organization = array(
'@type' => sanitize_text_field( (string) get_option( 'rankhigh_seo_publisher_type', 'NewsMediaOrganization' ) ),
'@id' => trailingslashit( PublicationProfile::primary_url() ) . '#organization',
'name' => PublicationProfile::publisher_name(),
'url' => PublicationProfile::primary_url(),
'inLanguage' => sanitize_text_field( (string) get_option( 'rankhigh_default_language', substr( (string) get_locale(), 0, 2 ) ) ),
);
$country = strtoupper( sanitize_text_field( (string) get_option( 'rankhigh_country', '' ) ) );
if ( $country ) {
$organization['areaServed'] = array( '@type' => 'Country', 'name' => $country );
}
$short_name = sanitize_text_field( (string) get_option( 'rankhigh_publication_short_name', '' ) );
if ( $short_name ) {
$organization['alternateName'] = $short_name;
}
if ( $logo_url ) {
$organization['logo'] = array( '@type' => 'ImageObject', 'url' => PublicationProfile::asset_url( $logo_url ) );
}
$social = PublicationProfile::social_profiles();
	if ( ! empty( $social ) ) {
	$organization['sameAs'] = $social;
	}
	$contact = sanitize_text_field( (string) get_option( 'rankhigh_contact', '' ) );
	if ( $contact ) { $organization['contactPoint'] = array( '@type' => 'ContactPoint', 'email' => $contact, 'contactType' => 'customer support' ); }
	$copyright = sanitize_text_field( (string) get_option( 'rankhigh_copyright', '' ) );
	if ( $copyright ) { $organization['copyrightNotice'] = $copyright; }
	return $organization;
	}
	/** @return array<string, mixed> */
	private function website() {
		$url = trailingslashit( PublicationProfile::primary_url() );
		return array(
			'@type' => 'WebSite',
			'@id' => $url . '#website',
			'url' => $url,
			'name' => PublicationProfile::publication_name(),
			'publisher' => array( '@id' => $url . '#organization' ),
			'inLanguage' => sanitize_text_field( (string) get_option( 'rankhigh_default_locale', get_bloginfo( 'language' ) ) ),
			'potentialAction' => array(
				'@type' => 'SearchAction',
				'target' => array( '@type' => 'EntryPoint', 'urlTemplate' => $url . '?s={search_term_string}' ),
				'query-input' => 'required name=search_term_string',
			),
		);
	}
/** @return array<string, mixed> */
	private function webpage() {
	$canonical = ( new \RankHighSEO\Meta\MetaGenerator() )->canonical();
	$page = array(
	'@type' => is_singular() ? 'WebPage' : 'CollectionPage',
	'@id' => trailingslashit( $canonical ) . '#webpage',
	'url' => $canonical,
	'name' => wp_get_document_title(),
	'inLanguage' => sanitize_text_field( (string) get_option( 'rankhigh_default_locale', get_bloginfo( 'language' ) ) ),
	);
	$page['isPartOf'] = array( '@id' => trailingslashit( PublicationProfile::primary_url() ) . '#website' );
	if ( is_singular() ) { $page['breadcrumb'] = array( '@id' => trailingslashit( $canonical ) . '#breadcrumb' ); }
	return $page;
	}
	/** @return array<string, mixed> */
	private function article() {
		$post = get_queried_object();
		$author = $post instanceof \WP_Post ? get_userdata( $post->post_author ) : false;
		$image = $post instanceof \WP_Post ? get_the_post_thumbnail_url( $post, 'full' ) : '';
		$permalink = (string) get_permalink( $post );
		$organization = $this->organization();
		$publisher = array(
			'@id' => $organization['@id'],
			'name' => $organization['name'],
		);
		if ( isset( $organization['logo'] ) ) {
			$publisher['logo'] = $organization['logo'];
		}
			$schema_type = (string) \RankHighSEO\Meta\PostMeta::get( $post->ID, \RankHighSEO\Meta\PostMeta::SCHEMA_TYPE, 'NewsArticle' );
			$article = array(
				'@type' => in_array( $schema_type, array( 'NewsArticle', 'Article', 'BlogPosting' ), true ) ? $schema_type : 'NewsArticle',
			'isAccessibleForFree' => true,
			'inLanguage' => sanitize_text_field( (string) get_option( 'rankhigh_default_language', substr( (string) get_locale(), 0, 2 ) ) ),
			'wordCount' => str_word_count( wp_strip_all_tags( (string) $post->post_content ) ),
			'@id' => trailingslashit( $permalink ) . '#article',
			'headline' => wp_strip_all_tags( (string) get_the_title( $post ) ),
			'datePublished' => get_post_time( DATE_W3C, true, $post ),
			'dateModified' => get_post_modified_time( DATE_W3C, true, $post ),
				'author' => array(
					'@type' => 'Person',
					'@id' => trailingslashit( $permalink ) . '#author',
					'name' => \RankHighSEO\Meta\PostMeta::get( $post->ID, \RankHighSEO\Meta\PostMeta::AUTHOR_NAME, '' ) ?: ( $author ? wp_strip_all_tags( (string) $author->display_name ) : __( 'Editorial staff', 'rankhigh-seo' ) ),
					'url' => $author ? (string) get_author_posts_url( $post->post_author ) : home_url( '/' ),
				),
			'publisher' => $publisher,
			'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => $permalink ),
			'articleSection' => $this->article_section( $post ),
			);
			if ( $image ) {
				$image_id = get_post_thumbnail_id( $post->ID );
				$image_meta = $image_id ? wp_get_attachment_metadata( $image_id ) : array();
				$article['image'] = array(
					'@type' => 'ImageObject',
					'url' => PublicationProfile::asset_url( $image ),
				);
				if ( ! empty( $image_meta['width'] ) ) { $article['image']['width'] = absint( $image_meta['width'] ); }
				if ( ! empty( $image_meta['height'] ) ) { $article['image']['height'] = absint( $image_meta['height'] ); }
			}
		$video = $this->video_object( $post, $image );
		if ( $video ) {
			$article['video'] = $video;
		}
		if ( $post instanceof \WP_Post && has_excerpt( $post ) ) {
			$article['description'] = wp_strip_all_tags( get_the_excerpt( $post ) );
		}
		$keywords = get_the_tags( $post->ID );
		if ( ! empty( $keywords ) && is_array( $keywords ) ) {
			$article['keywords'] = implode( ', ', wp_list_pluck( $keywords, 'name' ) );
		}
		return $article;
	}

	/** @param \WP_Post $post @param string $fallback_image @return array<string, mixed>|null */
	private function video_object( $post, $fallback_image ) {
		$thumbnail = (string) get_post_meta( $post->ID, \RankHighSEO\Meta\PostMeta::VIDEO_THUMBNAIL, true );
		$duration  = (string) get_post_meta( $post->ID, \RankHighSEO\Meta\PostMeta::VIDEO_DURATION, true );
		$content   = (string) $post->post_content;
		preg_match( '/https?:\\/\\/[^\\s"\'<>]+\\.(?:mp4|webm|mov)(?:\\?[^\\s"\'<>]+)?/i', $content, $matches );
		$content_url = ! empty( $matches[0] ) ? esc_url_raw( $matches[0] ) : '';
		if ( ! $content_url || ! $thumbnail ) {
			return null;
		}
		$video = array(
			'@type' => 'VideoObject',
			'name' => wp_strip_all_tags( (string) get_the_title( $post ) ),
			'description' => wp_strip_all_tags( get_the_excerpt( $post ) ),
			'thumbnailUrl' => PublicationProfile::asset_url( $thumbnail ? $thumbnail : $fallback_image ),
			'uploadDate' => get_post_time( DATE_W3C, true, $post ),
			'contentUrl' => $content_url,
		);
		if ( $duration ) {
			$video['duration'] = sanitize_text_field( $duration );
		}
		return $video;
	}

	/** @param \WP_Post $post @return string */
	private function article_section( $post ) {
		$categories = get_the_category( $post->ID );
		return ! empty( $categories ) ? (string) $categories[0]->name : __( 'News', 'rankhigh-seo' );
	}

	/** @return array<string, mixed> */
	private function breadcrumbs() {
		$post = get_queried_object();
		return array(
			'@type' => 'BreadcrumbList',
			'itemListElement' => array(
				array( '@type' => 'ListItem', 'position' => 1, 'name' => PublicationProfile::publication_name(), 'item' => PublicationProfile::primary_url() ),
				array( '@type' => 'ListItem', 'position' => 2, 'name' => $post instanceof \WP_Post ? get_the_title( $post ) : wp_get_document_title(), 'item' => ( new \RankHighSEO\Meta\MetaGenerator() )->canonical() ),
			),
		);
	}
}

/* EOF */
