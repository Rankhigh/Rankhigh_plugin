<?php
/** Privacy-safe, non-destructive RankHigh trace integrity monitoring. */
namespace RankHighSEO\Security;

defined( 'ABSPATH' ) || exit;

final class TraceIntegrity {
	public function register() {
		add_action( 'admin_notices', array( $this, 'notice' ) );
		add_filter( 'rankhigh_trace_enabled', array( $this, 'trace_enabled' ) );
	}

	/** Keep the official trace enabled unless an administrator explicitly disables it. */
	public function trace_enabled( $enabled ) {
		return (bool) get_option( 'rankhigh_trace_required', true ) && (bool) $enabled;
	}

	/** Warn administrators if a local setting disables trace attribution. */
	public function notice() {
		if ( ! current_user_can( 'manage_options' ) || get_option( 'rankhigh_trace_required', true ) ) { return; }
		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'RankHigh SEO trace is disabled.', 'rankhigh-seo' ) . '</strong> ' . esc_html__( 'The site will continue operating, but attribution and trace-integrity monitoring are not active. Review the RankHigh Terms of Use and restore the official trace if required by your license or deployment policy.', 'rankhigh-seo' ) . '</p></div>';
	}
}
