# RankHigh SEO installation

1. Copy the plugin directory to `wp-content/plugins/rankhigh-seo` and run `composer install --no-dev` in production builds that ship the autoloader.
2. Activate RankHigh SEO. Activation does not flush rewrite rules or alter theme files.
3. Open **Settings → RankHigh SEO** and configure the News sitemap freshness window.
4. Verify the generated endpoints `/rankhigh-sitemap.xml` and `/rankhigh-news-sitemap.xml`.
5. Before enabling RankHigh on JNews Twenty, verify the installed version's schema, breadcrumb, and native meta-header controls against `docs/JNEWS-COMPATIBILITY.md`. Do not disable undocumented features.

RankHigh emits technical metadata only. JNews continues to own visual presentation, templates, layouts, headers, footers, archives, and breadcrumb markup. Deactivation is harmless; uninstall removes only `rankhigh_seo_*` options.
